<?php
function my_content()
{
	//============ menu part ==============
	session_start();
	if (!isset($_SESSION["user_id"])) {
		if (isset($_COOKIE["user_id"]) && isset($_COOKIE["user_name"])) {
			$_SESSION["user_id"] = $_COOKIE["user_id"];
			$_SESSION["user_name"] = $_COOKIE["user_name"];
		}
	}

	// ========= navigation menu =========
	if (isset($_SESSION["user_name"])) {
		?>
		<div class="menu">
			<a href="B_Index.php?target_page=my&choose=all_my_article">All My Articles</a>
			<hr>
			<a href="B_Index.php?target_page=my&choose=new_my_article">Create New</a>
			<hr>
			Coming soon ...
		</div>
		<?php
	}

	$uid = $_SESSION["user_id"];
	$choose = $_GET["choose"];
	$aid = $_GET["article_id"];

	$obj = new Articles();
	$total = $obj->countArticle('', '', $uid)[0][0];
	$page = new Page($total, PAGE_SIZE);
	$limit = $page->limit;
	//$attr = $obj->listArticles('', '', $limit,$uid);
	//var_dump($page);

	$my_a_comment = new Comments();
	$my_a_comment_lists = $my_a_comment->listLatestComment($aid);

	$new_article_title = $new_article_content = "";
	$tt_ct_error = "";// title or content cannot empty

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$new_article_title = trim_input($_POST["new_article_title"]);
		$new_article_content = trim_input($_POST["new_article_content"]);
		$new_article_date = date('Y-m-d G-i-s');

		if (!empty($new_article_title) && !empty($new_article_content)) {
			session_start();

			$article_id = $obj->addArticle($new_article_title, $new_article_content, $new_article_date, $uid);

			if ($article_id) {
				header("Location: ./B_Index.php?target_page=my&choose=all_my_article&article_id=$article_id");
			}
		} else if (empty($new_article_title)) {
			$tt_ct_error = "Title cannot empty!";
		} else if (empty($new_article_content)) {
			$tt_ct_error = "Content cannot empty!";
		}
	}

	// list all my articles or one detail article
	if ($choose == 'all_my_article' || $choose == '') {
		// ========= all_my_article part =========
		?>
		<div class="content_menu" style="margin-left: -5px">
			<?php
			if (isset($aid)) {
			// ========= 选中的某一篇或者刚写完的那篇 =========
			$my_list_reads = $obj->listArticles("", "", "", "", $aid);
			show_article_detail($my_list_reads);
			?>

			<form method="post"
				  action="./B_Article_Delete.php?current_delete_article_id=<?php echo $_GET["article_id"]; ?>">
				<button type="submit" name="delete" style="margin-left: 5%; margin-bottom: 10px">Delete Now!</button>

				<?php
				show_article_comment($my_a_comment_lists);
				?>
				<?php
				} else {
					// ========= this is article list =========
					$my_lists = $obj->listArticles('', '', $limit, $uid);
					$target_page = 'my';
					show_article_list($my_lists, $total, $page, $target_page);
				}
				?>
		</div>
		<?php
	}
	// ================= create new article =================
	if ($choose == 'new_my_article') {
		?>
		<div class="content_menu">
			<form class="new_article_form" method="post" action="">
				<label for="a1">Title : </label><br/>
				<input id="a1" type="text" name="new_article_title" size="60"
					   value="<?php echo $new_article_title ?>"><br/>
				<label for="b1">Content : </label><br/>
				<textarea id="b1" name="new_article_content" cols="70" rows="15"></textarea>
				<br/>
				<button type="submit" name="new_article">Release Now!</button>
				<span class="error"> <?php echo $tt_ct_error; ?> </span><br/>
			</form>
		</div>
		<?php
	}
}