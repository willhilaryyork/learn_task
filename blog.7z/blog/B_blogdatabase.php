<?php
require 'configuration.php';

class Blog
{
	public $dbHost = DB_HOST;
	public $dbUsername = DB_USER_NAME;
	public $dbPassword = DB_USER_PASSWORD;
	public $database = DB_NAME;
	public $connection;

	//connect to Blog Database
	public function connect()
	{
		$this->connection = new mysqli($this->dbHost, $this->dbUsername, $this->dbPassword, $this->database);
		if ($this->connection->connect_errno) {
			printf("Connect Failed: %s\n", $this->connection->connect_error);
			exit();
		}
		return $this->connection;
	}

	//Convert blank space and enter to HTMLCode
	public function toHTMLCode($content)
	{
		return $result = str_replace("'", "&npbs;", str_replace("\r", "<br>", str_replace(" ", "&nbsp;", $content)));
	}

	//$flag==0 select statement  1 update/insert/delete statement
	protected function preventInjection($state, $param, $flag)
	{
		// sql statement
		$sql = $state;
		//prepare sql statement
		$stmt = $this->connection->prepare("$sql") or die($this->connection->error);
		$refs = [];
		if (!empty($param)) {
			foreach ($param as $key1 => $val1) {
				$refs[$key1] = &$param[$key1];
			}
			call_user_func_array([$stmt, 'bind_param'], $refs);
		}
		if ($flag == 1) {
			$result = $stmt->execute();
		} elseif ($flag == 0) {
			//execute prepared statement
			$stmt->execute();
			$arr = [];
			$stmt->field_count;
			$meta = $stmt->result_metadata();
			$i = 0;
			while ($field = $meta->fetch_field()) {
				$params[] = &$row[$i];
				$i++;
			}
			call_user_func_array([$stmt, 'bind_result'], $params);
			while ($stmt->fetch()) {
				foreach ($row as $key => $val) {
					$arr[$key] = $val;
				}
				$result[] = $arr;
			}
		}
		$stmt->close();
		return $result;
	}
}

class Users extends Blog
{
	//Login
	public function login($name, $password)
	{
		//connect to database
		self::connect();

		// use for count the select user info
		$name_pw_right = 0;
		$name_right = 0;
		$is_approved = 0;

		$state = "SELECT * FROM users WHERE user_name = ?";
		if ($name) {
			$param = ['s', $name];
			$result_item = self::preventInjection($state, $param, 0);
		}
		if (!empty($result_item)) {
			//Compare whether user_name and password equal to user table
			if (password_verify($password, $result_item[0][2])) {
				$name_pw_right += 1;
				if ($result_item[0][4] == 1) {
					$is_approved += 1;
				}
			} elseif (!password_verify($password, $result_item[0][2])) {
				$name_right += 1;
			}
			if ($is_approved) {
				$result [0][0] = $result_item[0][0];
				$result[0][1] = $result_item[0][3];
			} elseif (!$is_approved && $name_pw_right) {
				$result = "Username '" . $name . "' not approved.";
			} elseif ($name_right) {
				$result = "Password is wrong.";
			}
		}
		$this->connection->close();
		if (!empty($result)) {
			return $result;
		} else {
			return false;
		}
	}

	// Register, insert user info to user table
	public function register($name, $pw)
	{
		//connect to database
		self::connect();
		$passwordTemp = password_hash($pw, PASSWORD_DEFAULT);

		$state = "SELECT * FROM users WHERE user_name = ?";
		if ($name) {
			$param = ['s', $name];
			$result_item = self::preventInjection($state, $param, 0);
		}

		// insert user info into user table
		if (empty($result_item)) {
			$state1 = "INSERT INTO users(user_name,user_password) VALUES (?, ?)";
			$param1 = ['ss', $name, $passwordTemp];
			$result = self::preventInjection($state1, $param1, 1);
			$this->connection->close();
			return $result;
		} else {
			$this->connection->close();
			return false;
		}
	}

	//list users except self
	public function listUsers($name)
	{
		//connect to database
		self::connect();
		//list users except self
		$state = "SELECT * FROM users WHERE user_name <> ?";
		$param = ['s', $name];
		$result = self::preventInjection($state, $param, 0);
		foreach ($result as $key => $value) {
			array_splice($result[$key], 2, 1);
		}
		$this->connection->close();
		return $result;
	}

	//update users permission, $permission = 1 =>user_is_approved, $permission = 2 =>
	public function updateUsers($name, $permission = 0)
	{
		//connect to database
		self::connect();
		$param = ['s', $name];
		//update users permission
		if ($name && $permission == 1) {
			$state = "UPDATE users SET user_is_admin = 1,user_is_approved = 1 WHERE user_name = ?";
			$result = self::preventInjection($state, $param, 1);
			$this->connection->close();
			return $result;
		} elseif ($name && $permission == 2) {
			$state1 = "UPDATE users SET user_is_approved = 1 WHERE user_name = ?";
			$result = self::preventInjection($state1, $param, 1);
			$this->connection->close();
			return $result;
		} else {
			return false;
		}
	}
}

class Articles extends Blog
{
	// Create a article, insert to article table
	public function addArticle($title, $content, $date, $userId)
	{
		//connect to database
		self::connect();
		// assign article title and content
		$articleTitle = $this->toHTMLCode($title);
		$articleContent = $this->toHTMLCode($content);
		// Insert article to article table
		if ($articleTitle && $articleContent && $userId) {
			$state = "INSERT INTO articles(article_title, article_content, article_created_date, article_user_id) VALUES ( ?, ?, ?, ?)";
			$param = ['sssi', $articleTitle, $articleContent, $date, $userId];
			self::preventInjection($state, $param, 1);
		}
		$state1 = "SELECT * FROM articles WHERE article_title = ? and article_created_date = ? and article_user_id = ?";
		$param1 = ['ssi', $articleTitle, $date, $userId];
		$result = self::preventInjection($state1, $param1, 0);
		$article_id = intval($result[0][0]);
		mysqli_close($this->connection);
		if (!empty($result)) {
			return $article_id;
		} else {
			return false;
		}
	}

	//Delete Article
	public function deleteArticle($articleId)
	{
		//connect to database
		self::connect();

		if ($articleId) {
			$state = "DELETE FROM comments WHERE comment_article_id = ?";
			$param = ['i', $articleId];
			$re1 = self::preventInjection($state, $param, 1);
			$state1 = "DELETE FROM articles WHERE article_id = ?";
			$re2 = self::preventInjection($state1, $param, 1);
		}
		if ($re1 && $re2) {
			$result = $re1;
		}
		return $result;
//		$result = mysqli_fetch_all(mysqli_query($this->connection,
//			"SELECT * FROM articles WHERE article_id = '$articleId'"));
//		mysqli_close($this->connection);
//		if (!empty($result)) {
//			return false;
//		} else {
//			return true;
//		}
	}

	//Update a article
	public function updateArticle($articleId, $title, $content, $date)
	{
		//connect to database
		self::connect();

		$articleTitle = $this->toHTMLCode($title);
		$articleContent = $this->toHTMLCode($content);

		if ($articleTitle && $articleContent && $date) {
			$state1 = "UPDATE articles SET article_title = '$articleTitle', article_content = '$articleContent', article_created_date = '$date' WHERE  article_id = ?";
			$param1 = ['i', $articleId];
			$result = self::preventInjection($state1, $param1, 1);
		}
		if ($result) {
			return true;
		} else {
			return false;
		}
	}

	//List articles
	public function listArticles($search_text = "", $date = "", $limit = "", $user_id = "", $article_id = "")
	{
		//connect to database
		self::connect();
		$str1 = "SELECT article_id,article_title,article_content,article_created_date,article_user_id,user_name
FROM articles LEFT JOIN users ON articles.article_user_id =users.user_id ";
		$str2 = " ORDER BY article_created_date DESC ";
		$str3 = " LIMIT ";
		if (!empty($limit)) {
			$arr = explode(",", $limit);
			$str = implode(" ", $arr);
			$arr1 = explode(" ", $str);
			if (empty($search_text) && empty($date) && empty($user_id) && empty($article_id)) {
				$state = $str1 . $str2 . $str3 . " ?,?";
				$param = ['ii', $arr1[1], $arr1[3]];
			} elseif (!empty($search_text)) {
				$state = $str1 . "WHERE MATCH (article_title,article_content) AGAINST (? IN BOOLEAN MODE)" . $str2 . $str3 . " ?, ?";
				$param = ['sii', $search_text, $arr1[1], $arr1[3]];
			} elseif (!empty($date)) {
				$state = $str1 . "WHERE DATE_FORMAT(article_created_date,'%Y-%m-%d') = DATE_FORMAT( ?,'%Y-%m-%d')" . $str2 . $str3 . " ?,?";
				$param = ['sii', $date, $arr1[1], $arr1[3]];
			} elseif (!empty($user_id)) {
				$state = $str1 . "WHERE article_user_id = ? " . $str2 . $str3 . " ?,?";
				$param = ['iii', $user_id, $arr1[1], $arr1[3]];
			}
		} else {
			if (empty($search_text) && empty($date) && empty($user_id) && empty($article_id)) {
				$state = $str1 . $str2;
				$param = "";
			} elseif (!empty($search_text)) {
				$state = $str1 . "WHERE MATCH (article_title,article_content) AGAINST (? IN BOOLEAN MODE)" . $str2;
				$param = ['s', $search_text];
			} elseif (!empty($date)) {
				$state = $str1 . "WHERE DATE_FORMAT(article_created_date,'%Y-%m-%d') = DATE_FORMAT( ?,'%Y-%m-%d')" . $str2;
				$param = ['s', $date];
			} elseif (!empty($user_id)) {
				$state = $str1 . "WHERE article_user_id = ? " . $str2;
				$param = ['i', $user_id];
			} elseif (!empty($article_id)) {
				$state = $str1 . "WHERE article_id = ? " . $str2;
				$param = ['i', $article_id];
			}
		}
		$result = self::preventInjection($state, $param, 0);
		$this->connection->close();
		if (!empty($result)) {
			return $result;
		} else {
			return false;
		}
	}

	//count article
	public function countArticle($search_text = "", $date = "", $user_id = "")
	{
		//connect to database
		self::connect();
		$str1 = "SELECT count(*) as amount FROM articles ";
		if (empty($search_text) && empty($date) && empty($user_id)) {
			$state = $str1;
			$param = "";
		} elseif (!empty($search_text)) {
			$state = $str1 . "WHERE MATCH (article_title,article_content) AGAINST (? IN BOOLEAN MODE)";
			$param = ['s', $search_text];
		} elseif (!empty($date)) {
			$state = $str1 . "WHERE DATE_FORMAT(article_created_date,'%Y-%m-%d') = DATE_FORMAT( ?,'%Y-%m-%d')";
			$param = ['s', $date];
		} elseif (!empty($user_id)) {
			$state = $str1 . "WHERE article_user_id = ?";
			$param = ['i', $user_id];
		}
		$result = self::preventInjection($state, $param, 0);
		mysqli_close($this->connection);
		if (!empty($result)) {
			return $result;
		} else {
			return false;
		}
	}
}

class Comments extends Blog
{
	//add comment
	public function addComment($text, $date, $userId = NULL, $articleId)
	{
		//connect to database
		self::connect();
		$str1 = "INSERT INTO comments(comment_text,comment_created_date,comment_user_id,comment_article_id) VALUES ";
		// assign comment text
		$commentText = $this->toHTMLCode($text);
		// Insert comment text to comment table
		$state = $str1 . " (?,?,?,?)";
		$param = ['ssii', $commentText, $date, $userId, $articleId];
		self::preventInjection($state, $param, 1);
		$state1 = "SELECT * FROM comments WHERE comment_text = ?  
		and comment_created_date = ? and comment_article_id = ? ";
		$param1 = ['ssi', $commentText, $date, $articleId];
		$result = self::preventInjection($state1, $param1, 0);
		$commentId = intval($result[0][0]);
		$this->connection->closed;
		mysqli_close($this->connection);
		if (!empty($result)) {
			return $commentId;
		} else {
			return false;
		}
	}

	//List comment
	public function listLatestComment($articleID)
	{
		//connect to database
		self::connect();
		$str1 = "SELECT comment_id,comment_text,comment_created_date,comment_article_id,comment_user_id,user_name FROM comments LEFT JOIN users ON comments.comment_user_id =users.user_id ";
		$str2 = " ORDER BY comment_created_date DESC ";
		$state = $str1 . "WHERE comment_article_id = ?" . $str2;
		$param = ['i', $articleID];
		$result = self::preventInjection($state, $param, 0);
		mysqli_close($this->connection);
		if (!empty($result)) {
			return $result;
		} else {
			return false;
		}
	}

	//delete comment
	public function deleteComment($commentId)
	{
		//connect to database
		self::connect();
		$state = "DELETE FROM comments WHERE comment_id = '$commentId'";
		$param = ['i', $commentId];
		$result = self::preventInjection($state, $param, 1);
		mysqli_close($this->connection);
		if ($result) {
			return true;
		} else {
			return false;
		}
	}
}

function toHTML($content)
{
	return $result = str_replace("&npbs;", "'", $content);  // $nbps; convert to '
}

function trim_input($data)
{
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
