
$(document).ready(function () {
	$('#check_all_admin').click(function () {
		if ($(this).prop("checked") == true) {
			$(".check_admin").prop("checked", true);
			$("#check_all_approved").prop("checked", true);
			$(".check_approved").prop("checked", true);
		} else {
			$(".check_admin").prop("checked", false);
			$("#check_all_approved").prop("checked", false);
			$(".check_approved").prop("checked", false);
		}
	});
	$('#check_all_approved').click(function () {
		if ($(this).prop("checked") == true) {
			$(".check_approved").prop("checked", true);
		} else {
			$(".check_approved").prop("checked", false);
		}
	});
	$('.check_admin').click(function () {
		if ($(this).prop("checked") == true) {
			var val1=$(this).val().substring(6);
			$(".check_approved").each(function () {
				var val2=$(this).val().substring(9);
				if(val1==val2)
				{
					$(this).prop("checked", true);
				}
			});
		}
	});
});

