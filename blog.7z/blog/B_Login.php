<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login</title>
	<link rel="stylesheet" href="B_custom.css" type="text/css">
	<link rel="stylesheet" href="B_Login_Register.css" type="text/css">
</head>
<body class="login">

<div id="L_R">
	<?php
	if ($_GET['action'] == 'register') {
		//echo "register" . "<br/>";
		include 'B_blogdatabase.php';

		// define variable and set blank
		$username = $password1 = $password2 = "";
		$nm_pw_error = "";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			if (isset($_POST['reg-submit'])) {
				$username = trim_input($_POST["reg_name"]);
				$password1 = trim_input($_POST["reg_password1"]);
				$password2 = trim_input($_POST["reg_password2"]);
				if (!empty($username) && !empty($password1) && $password1 == $password2) {
					//-------------------------------------------------------------------
					$regtest = new Users();
					$is_reged = $regtest->register($username, $password2);
					if ($is_reged) {
						header("Location: ./B_Login.php");
					} else {
						$nm_pw_error = "Username  '". $username ."' had been registered.";
					}
				} else if (empty($username)) {
					$nm_pw_error = "Username cannot empty!";
				} else if (empty($password1)) {
					$nm_pw_error = "Please input password!";
				} else if (!empty($password1) && $password1 != $password2) {
					$nm_pw_error = "Please conform input same password!";
				} else {
					$nm_pw_error = "Please input again!";
				}
			}else {
				$home_url = "B_Login.php?action=register";
				header("Location: " . $home_url);
			}
		}
		?>
		<form name="registerform" action="" method="post" novalidate="novalidate">
			<p>
				<label for="reg_name" class="label_tip">Username<br/>
					<input type="text" name="reg_name" value="<?php echo $username; ?>" autofocus="autofocus" size="20"/></label>
			</p>

			<p>
				<label for="reg_password1" class="label_tip">Password<br/>
					<input type="password" name="reg_password1" value="" size="25"/></label>
			</p>

			<p>
				<label for="reg_password2" class="label_tip">Conform<br/>
					<input type="password" name="reg_password2" value="" size="25"/></label>
			</p>

			<p class="label_tip2">* Registration result will inform you later.</p>

			<p>
				<input type="submit" name="reg-submit" value="Register"/>
				<?php
				if (!empty($nm_pw_error)){
				?>
			<p>
				<span class="label_tip_error"> <?php echo $nm_pw_error; ?> </span>
			</p>
			<?php
			} else {
			}
			?>
			<p>
				<a href="B_Login.php" class="label_tip3"> I have an account, login now! </a>
			</p>

		</form>
		<?php
	} else {
		//echo "login" . "<br/>";
		include 'B_blogdatabase.php';

// define variable and set blank
		$username = $password = "";
		$nm_pw_error = "";
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$username = trim_input($_POST["log_name"]);
			$password = trim_input($_POST["log_pwd"]);
			//------------------------------------------------------
			$obj = new Users();
			session_start();
			if (!isset($_SESSION["user_id"])) {
				if (isset($_POST['log-submit'])) {
					if ($username && $password) {
						$log = $obj->login($username, $password);
						if ($log != false) {
							if(is_array($log))
							{
							$_SESSION["user_id"] = $log[0][0];
							$_SESSION["user_name"] = $username;
							$_SESSION["is_admin"] = $log[0][1];
//							setcookie("user_id", $log[0][0], time()+(60*60*24*30));
//							setcookie("username", $username, time()+(60*60*24*30));
							$home_url = "B_Index.php";
							header("Location: " . $home_url);
							exit;
							}else{
								$nm_pw_error = $log;
							}
						} else {
							$nm_pw_error= "Username '".$username."' not exist.";
						}
					}else if (empty($username)) {
						$nm_pw_error = "Username cannot empty!";
					}else if (empty($password)) {
						$nm_pw_error = "Please input password!";
					}
				}
			} else {
				$home_url = "B_Login.php";
				header("Location: " . $home_url);
			}
		}
		?>
		<form name="loginform" action="" method="post">
			<p>
				<label for="log_name" class="label_tip">Username<br/>
					<input type="text" name="log_name" value="<?php echo $username; ?>" autofocus="autofocus" size="20"/></label></p>

			<p>
				<label for="log_pwd" class="label_tip">Password<br/>
					<input type="password" name="log_pwd" value="" size="20"/></label></p>

			<p>
				<input type="submit" name="log-submit" value="Log In"/>
				<?php
				if (!empty($nm_pw_error)){
				?>
			<p>
				<span class="label_tip_error"> <?php echo $nm_pw_error; ?> </span>
			</p>
			<?php
			} else {
			}
			?>
			</p>

			<p>
				<a href="B_Login.php?action=register" class="label_tip3"> No account? Register now! </a>
			</p>

		</form>
		<?php
	}
	?>
</div>
</body>
</html>