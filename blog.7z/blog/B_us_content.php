<?php
/**
 * Created by PhpStorm.
 * User: yz
 * Date: 2016/8/9
 * Time: 10:01
 */
function us_content()
{
	//echo "us page"."<br/>";
	?>
	<div align="center" style="margin: 20px">
	<img style="margin: 20px" src="B_img/human_01.png">
	<img style="margin: 20px" src="B_img/human_02.png">
	</div>
<?php
}