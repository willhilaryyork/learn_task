#!/bin/sh
su git -c "/home/git/gogs/scripts/gogs_supervisord.sh restart"
