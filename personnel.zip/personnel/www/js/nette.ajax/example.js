$(function () {
	$.nette.init();
	// And you fly...
});
