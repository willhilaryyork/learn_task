Personnel
=============

Installing
----------

Run following commands:
		git clone http://10.160.32.130:3000/kids/personnel.git personnel
		cd personnel
		composer install

Create your `config.local.neon` and set your database connection,
Follow example in `config.local.sample.neon`:
		parameters:
			dbal:
				driver: mysqli
				host: 127.0.0.1
				username: your_username
				password: your_password
				database: your_database_name

Make directories `temp` and `log` writable.

Run migrations:
		cd {wwwroot path}/personnel
		php www/index.php migrations:continue

Navigate your browser to the `www` directory and you will see a homepage.

It is CRITICAL that whole `app`, `log`, `temp` and `migrations` directories are NOT accessible
directly via a web browser! See [security warning](https://nette.org/security-warning).