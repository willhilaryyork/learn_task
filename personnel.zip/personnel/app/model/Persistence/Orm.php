<?php

namespace App\Model\Persistence;

use App\Model\Persistence\Employees\EmployeesRepository;
use App\Model\Persistence\JobTitles\JobTitlesRepository;
use App\Model\Persistence\Organizations\OrganizationsRepository;
use App\Model\Persistence\OrganizationTypes\OrganizationTypesRepository;
use App\Model\Persistence\Persons\PersonsRepository;
use App\Model\Persistence\Positions\PositionsRepository;
use App\Model\Persistence\Responsibilities\ResponsibilitiesRepository;
use App\Model\Persistence\UserAccounts\UserAccountsRepository;
use Nextras\Orm\Model\Model;


/**
 * @property-read EmployeesRepository $employees
 * @property-read PersonsRepository $persons
 * @property-read JobTitlesRepository $jobTitles
 * @property-read ResponsibilitiesRepository $responsibilities
 * @property-read OrganizationsRepository $organizations
 * @property-read OrganizationTypesRepository $organizationTypes
 * @property-read PositionsRepository $positions
 * @property-read UserAccountsRepository $userAccounts
 */
class Orm extends Model
{

}