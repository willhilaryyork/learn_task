<?php

namespace App\Model\Persistence\Positions;

use Nextras\Orm\Mapper\Mapper;


class PositionsMapper extends Mapper
{

}