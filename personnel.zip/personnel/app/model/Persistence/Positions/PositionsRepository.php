<?php

namespace App\Model\Persistence\Positions;

use Nextras\Orm\Repository\Repository;


class PositionsRepository extends Repository
{
	/**
	 * Returns possible entity class names for current repository.
	 * @return string[]
	 */
	public static function getEntityClassNames()
	{
		return [Position::class];
	}
	
}