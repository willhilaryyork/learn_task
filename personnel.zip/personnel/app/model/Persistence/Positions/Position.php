<?php

namespace App\Model\Persistence\Positions;

use App\Model\Persistence\Employees\Employee;
use App\Model\Persistence\Organizations\Organization;
use App\Model\Persistence\JobTitles\JobTitle;
use Nextras\Orm\Entity\Entity;
use Nextras\Orm\InvalidStateException;


/**
 * @property-read int $id {primary}
 * @property Employee $employee {m:1 Employee::$positions}
 * @property Organization $organization {m:1 Organization::$positions}
 * @property JobTitle $jobTitle {m:1 JobTitle, oneSided=true}
 * @property bool $isDirector {default false}
 */
class Position extends Entity
{
	protected function onAfterPersist()
	{
		if ($this->getRepository()
				->findBy(['organization' => $this->organization, 'isDirector' => true])
				->count() > 1
		)
			throw new InvalidStateException('Organization "' . $this->organization->name .
				'" already has a director.');

		if ($this->getRepository()
				->findBy(['organization' => $this->organization, 'employee' => $this->employee])
				->count() > 1
		)
			throw new InvalidStateException('Already has a jobTitle in "' . $this->organization->name);
	}

}