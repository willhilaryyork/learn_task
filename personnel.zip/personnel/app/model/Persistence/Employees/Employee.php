<?php

namespace App\Model\Persistence\Employees;

use App\Model\Persistence\Persons\Person;
use App\Model\Persistence\Positions\Position;
use App\Model\Persistence\Responsibilities\Responsibility;
use DateTime;
use Nextras\Orm\Entity\Entity;
use Nextras\Orm\Relationships\ManyHasMany;
use Nextras\Orm\Relationships\OneHasMany;


/**
 * @property-read int $id {primary}
 * @property string $firstName
 * @property string $lastName
 * @property string $name {virtual}
 * @property Person|NULL $personalInfo {1:1 Person::$employeeInfo, isMain=true}
 * @property string $employeeNumber
 * @property DateTime $dateOfHire
 * @property string|NULL $personalEmail
 * @property ManyHasMany|Responsibility[] $responsibilities {m:n Responsibility, isMain=true, oneSided=true}
 * @property OneHasMany|Position[] $positions {1:m Position::$employee}
 */
class Employee extends Entity
{
	protected function getterName()
	{
		return $this->firstName . ' ' . $this->lastName;
	}


	// for fetchPairs in Organization entity
	function __toString()
	{
		return $this->id . '-' . $this->employeeNumber;
	}

}