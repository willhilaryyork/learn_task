<?php

namespace App\Model\Persistence\Employees;

use Nextras\Orm\Mapper\Mapper;


class EmployeesMapper extends Mapper
{
	public function searchEmployee($searchContent)
	{
		$searchArr = explode(' ', $searchContent);
		$builder = $this->connection->createQueryBuilder();
		$builder->from('employees');
		if (count($searchArr) <= 1) {
			$builder->andWhere('employee_number LIKE %_like_', $searchContent);
			$builder->orWhere('first_name LIKE %_like_', $searchContent);
			$builder->orWhere('last_name LIKE %_like_', $searchContent);
		} else {
			foreach ($searchArr as $value) {
				$builder->andWhere('employee_number LIKE %_like_ OR first_name LIKE %_like_ OR last_name LIKE %_like_', $value, $value, $value);
			}
		}

		return $this->connection->queryArgs($builder->getQuerySql(), $builder->getQueryParameters());
	}
}