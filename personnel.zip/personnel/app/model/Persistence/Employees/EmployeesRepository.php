<?php

namespace App\Model\Persistence\Employees;

use Nextras\Orm\Repository\Repository;


class EmployeesRepository extends Repository
{
	/**
	 * Returns possible entity class names for current repository.
	 * @return string[]
	 */
	public static function getEntityClassNames()
	{
		return [Employee::class];
	}
	
}