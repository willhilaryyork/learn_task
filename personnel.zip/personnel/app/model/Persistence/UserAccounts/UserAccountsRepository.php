<?php

namespace App\Model\Persistence\UserAccounts;

use Nextras\Orm\Repository\Repository;


class UserAccountsRepository extends Repository
{
	/**
	 * Returns possible entity class names for current repository.
	 * @return string[]
	 */
	public static function getEntityClassNames()
	{
		return [UserAccount::class];
	}

}