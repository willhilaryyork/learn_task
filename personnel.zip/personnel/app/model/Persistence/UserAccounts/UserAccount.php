<?php

namespace App\Model\Persistence\UserAccounts;

use App\Model\Persistence\Employees\Employee;
use Nette\Security\Passwords;
use Nextras\Orm\Entity\Entity;


/**
 * @property-read int $id {primary}
 * @property-read string|NULL $username
 * @property-read string|NULL $password
 * @property-read bool $isActive {default false}
 * @property-read Employee|NULL $employee {m:1 Employee, oneSided=true}
 * @property-read string|NULL $newcomerKey
 * @property-read bool $isAdmin {default false}
 */
class UserAccount extends Entity
{
	public function __construct(Employee $employee)
	{
		parent::__construct();
		$this->setReadOnlyValue('employee', $employee);

		//todo: later change for real UUID
		$this->setReadOnlyValue('newcomerKey', $this->getUniqueKey($employee->employeeNumber));
	}


	public function setAsAdmin()
	{
		$this->setReadOnlyValue('isAdmin', true);
	}


	/**
	 * Activate newcomer user account.
	 * Method provide hash function automatically.
	 *
	 * @param string $username
	 * @param string $password plain text
	 */
	public function activate($username, $password)
	{
		if (Passwords::needsRehash($password))
			$password = Passwords::hash($password);

		$this->setReadOnlyValue('username', $username);
		$this->setReadOnlyValue('password', $password);
		$this->setReadOnlyValue('isActive', TRUE);
		$this->setReadOnlyValue('newcomerKey', NULL);
	}


	/**
	 * @param string $password plain text
	 */
	public function changePassword($password)
	{
		if (Passwords::needsRehash($password))
			$password = Passwords::hash($password);

		$this->setReadOnlyValue('password', $password);
	}


	/**
	 * @param string $password plain text
	 * @return bool
	 */
	public function verifyPassword($password)
	{
		return Passwords::verify($password, $this->password);
	}


	private function getUniqueKey($employeeNumber)
	{
		$uniqID = uniqid('', FALSE);
		$key = $employeeNumber;

		$uniqIDExplode = [];
		for ($i = 0; $i < strlen($uniqID); $i++) {
			$uniqIDExplode[] = substr($uniqID, $i, 1);
		}
		$keyExplode = [];
		for ($i = 0; $i < strlen($key); $i++) {
			$keyExplode[] = substr($key, $i, 1);
		}

		$uniqArray = [];
		$cnt = 0;
		while ((count($uniqIDExplode) + count($keyExplode)) != 0) {
			if (!empty($uniqIDExplode))
				$uniqArray[] = array_shift($uniqIDExplode);
			$cnt++;
			if (((count($uniqIDExplode) + count($keyExplode)) != 0) && $cnt % 5 === 0)
				$uniqArray[] = '-';
			if (!empty($keyExplode))
				$uniqArray[] = array_shift($keyExplode);
			$cnt++;
			if (((count($uniqIDExplode) + count($keyExplode)) != 0) && $cnt % 5 === 0)
				$uniqArray[] = '-';
		}

		return implode('', $uniqArray);
	}

}