<?php

namespace App\Model\Persistence\UserAccounts;

use Nextras\Orm\Mapper\Mapper;


class UserAccountsMapper extends Mapper
{

}