<?php

namespace App\Model\Persistence\Organizations;

use Nextras\Orm\Mapper\Mapper;


class OrganizationsMapper extends Mapper
{

}