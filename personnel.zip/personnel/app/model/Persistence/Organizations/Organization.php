<?php

namespace App\Model\Persistence\Organizations;

use App\Model\Persistence\Employees\Employee;
use App\Model\Persistence\OrganizationTypes\OrganizationType;
use App\Model\Persistence\Positions\Position;
use Nextras\Orm\Entity\Entity;
use Nextras\Orm\Relationships\OneHasMany;


/**
 * @property-read int $id {primary}
 * @property string $name
 * @property OrganizationType $type {m:1 OrganizationType, oneSided=true}
 * @property Organization|NULL $parentOrganization {m:1 Organization::$subOrganizations}
 * @property OneHasMany|Organization[] $subOrganizations {1:m Organization::$parentOrganization}
 * @property OneHasMany|Position[] $positions {1:m Position::$organization} <br> Get positions
 * within this organization.
 * @property-read Position[] $allPositions {virtual} <br> Get positions from whole organization
 * including sub organizations.
 *
 * @property-read Employee[] $members {virtual} <br> Get employees  within this organization.
 * @property-read Employee|NULL $director {virtual}
 * @property-read Employee[] $subordinates {virtual} Get subordinates  within this organization.
 * @property-read Employee[] $allMembers {virtual} <br> Get positions from whole organization
 * including sub organizations.
 * @property-read Employee[] $allSubordinates {virtual} <br> Except director of this organization
 * get positions from whole organization including sub organizations.
 */
class Organization extends Entity
{
	protected function getterAllPositions()
	{
		$positions = $this->positions->get()->fetchAll();
		foreach ($this->subOrganizations as $child) {
			$positions = array_merge($positions, $child->allPositions);
		}
		return $positions;
	}


	protected function getterDirector()
	{
		if ($position = $this->positions->get()->getBy(['isDirector' => TRUE]))
			return $position;
		else
			return NULL;
	}


	protected function getterMembers()
	{
		return array_values($this->namedFetchMembers());
	}


	protected function getterAllMembers()
	{
		$members = $this->namedFetchMembers();
		foreach ($this->subOrganizations as $child) {
			$members = array_merge($members, $child->namedFetchMembers());
		}
		return array_values($members);
	}


	protected function getterSubordinates()
	{
		return array_values($this->namedFetchSubordinates());
	}


	protected function getterAllSubordinates()
	{
		$subordinates = $this->namedFetchSubordinates();
		foreach ($this->subOrganizations as $child) {
			$subordinates = array_merge($subordinates, $child->namedFetchMembers());
		}
		return array_values($subordinates);
	}


	/**
	 * @return array
	 */
	public function namedFetchMembers()
	{
		return $this->positions->get()->fetchAll();
	}


	/**
	 * @return array
	 */
	public function namedFetchSubordinates()
	{
		return $this->positions->get()->findBy(['isDirector' => FALSE])->fetchAll();
	}

}