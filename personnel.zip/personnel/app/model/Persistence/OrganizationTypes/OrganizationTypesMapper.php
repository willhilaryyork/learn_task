<?php

namespace App\Model\Persistence\OrganizationTypes;

use Nextras\Orm\Mapper\Mapper;


class OrganizationTypesMapper extends Mapper
{

}