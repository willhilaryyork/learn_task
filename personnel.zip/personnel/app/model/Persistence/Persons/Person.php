<?php

namespace App\Model\Persistence\Persons;

use App\Model\Persistence\Employees\Employee;
use DateTime;
use Nextras\Orm\Entity\Entity;


/**
 * @property-read int $id {primary}
 * @property Employee $employeeInfo {1:1 Employee::$personalInfo}
 * @property DateTime $dateOfBirth
 * @property string $placeOfBirth
 * @property string $gender {enum self::GENDER_*}
 * @property string $maritalStatus {enum self::MARITAL_STATUS_*}
 * @property string $nationality
 * @property string $permanentStay
 * @property string $personalIdentityNumber
 * @property string $personalPhoneNumber
 */
class Person extends Entity
{
	const GENDER_MALE = 'Male',
		GENDER_FEMALE = 'Female';

	const MARITAL_STATUS_MARRIED = 'Married',
		MARITAL_STATUS_SINGLE = 'Single',
		MARITAL_STATUS_DIVORCED = 'Divorced',
		MARITAL_STATUS_WIDOWED = 'Widowed',
		MARITAL_STATUS_LIVING_COMMON_LAW = 'Living common law',
		MARITAL_STATUS_SEPARATED = 'Separated';

}