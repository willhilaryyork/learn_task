<?php

namespace App\Model\Persistence\Persons;

use Nextras\Orm\Repository\Repository;


class PersonsRepository extends Repository
{
	/**
	 * Returns possible entity class names for current repository.
	 * @return string[]
	 */
	public static function getEntityClassNames()
	{
		return [Person::class];
	}
	
}