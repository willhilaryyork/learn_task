<?php

namespace App\Model\Persistence\Persons;

use Nextras\Orm\Mapper\Mapper;


class PersonsMapper extends Mapper
{

}