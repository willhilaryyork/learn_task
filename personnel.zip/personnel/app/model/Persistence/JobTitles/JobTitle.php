<?php

namespace App\Model\Persistence\JobTitles;

use Nextras\Orm\Entity\Entity;


/**
 * @property-read int $id {primary}
 * @property string $name
 * @property string|NULL $description
 */
class JobTitle extends Entity
{

}