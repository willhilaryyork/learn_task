<?php

namespace App\Model\Persistence\JobTitles;

use Nextras\Orm\Mapper\Mapper;


class JobTitlesMapper extends Mapper
{

}