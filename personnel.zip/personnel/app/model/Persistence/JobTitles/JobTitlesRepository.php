<?php

namespace App\Model\Persistence\JobTitles;

use Nextras\Orm\Repository\Repository;


class JobTitlesRepository extends Repository
{
	/**
	 * Returns possible entity class names for current repository.
	 * @return string[]
	 */
	public static function getEntityClassNames()
	{
		return [JobTitle::class];
	}

}