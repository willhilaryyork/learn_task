<?php

namespace App\Model\Persistence\Responsibilities;

use Nextras\Orm\Mapper\Mapper;


class ResponsibilitiesMapper extends Mapper
{

}