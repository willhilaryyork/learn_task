<?php

namespace App\Model;


use Nette\Http\SessionSection;

class SessionService
{
	public function arrayToSection(SessionSection $section, $arr)
	{
		foreach ($arr as $key => $value) {
			$section->$key = $arr[$key];
		}
	}
}