<?php

namespace App\Model;

use App\Model\Persistence\UserAccounts\UserAccount;
use App\Model\Persistence\UserAccounts\UserAccountsRepository;
use Nette\InvalidArgumentException;

class Register
{
	/**
	 * @var UserAccountsRepository $userAccountsRepository
	 */
	private $userAccountsRepository;

	public function __construct(UserAccountsRepository $userAccountsRepository)
	{
		$this->userAccountsRepository = $userAccountsRepository;
	}

	public function verifyUsernamePassword($username, $password, $passwordConfirm)
	{
		/** @var UserAccount $user */
		$user = $this->userAccountsRepository->findBy(['username' => $username])->fetch();
		if ($user)
			throw new InvalidArgumentException("User '" . $username . "' duplicate!");
		if ($passwordConfirm != $password)
			throw new InvalidArgumentException("Please key in same password!");
	}
}