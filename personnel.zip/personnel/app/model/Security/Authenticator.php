<?php

namespace App\Model\Authenticator;

use App\Model\Persistence\UserAccounts\UserAccount;
use App\Model\Persistence\UserAccounts\UserAccountsRepository;
use Nette\Security\AuthenticationException;
use Nette\Security\IAuthenticator;
use Nette\Security\Identity;
use Nette\Security\IIdentity;
use Nette\Security\Passwords;


class Authenticator implements IAuthenticator
{
	/**
	 * @var UserAccountsRepository $userAccountsRepository
	 */
	private $userAccountsRepository;

	public function __construct(UserAccountsRepository $userAccountsRepository)
	{
		$this->userAccountsRepository = $userAccountsRepository;
	}

	/**
	 * Performs an authentication against e.g. database.
	 * and returns IIdentity on success or throws AuthenticationException
	 * @param array $credentials
	 * @return IIdentity
	 * @throws AuthenticationException
	 */
	function authenticate(array $credentials)
	{
		list($username, $password) = $credentials;

		/** @var UserAccount $user */
		$user = $this->userAccountsRepository->findBy(['username' => $username])->fetch();

		if (!$user) {
			throw new AuthenticationException("User '" . $username . "' not found", self::IDENTITY_NOT_FOUND);
		} elseif (!Passwords::verify($password, $user->password)) {
			throw new AuthenticationException('Invalid password', self::INVALID_CREDENTIAL);
		} elseif (!$user->isActive) {
			throw new AuthenticationException('User not active', self::INVALID_CREDENTIAL);
		} else {
			if ($user->employee) {
				$employee = [
					'username' => $user->username,
					'employeeId' => $user->employee->id,
					'employeeFirstName' => $user->employee->firstName,
					'employeeLastName' => $user->employee->lastName,
					'dateOfHire' => $user->employee->dateOfHire,
					'isAdmin' => $user->isAdmin,
				];
			} else {
				$employee = [
					'username' => $user->username,
					'isAdmin' => $user->isAdmin,
				];
			}

			return new Identity($user->id, $user->username, $employee);
		}
	}
}