<?php

namespace App\Model;


use App\Model\Persistence\Organizations\Organization;
use App\Model\Persistence\Orm;
use App\Model\Persistence\Positions\Position;
use App\Model\Persistence\UserAccounts\UserAccount;

class OrgChart
{
	/** @var  Orm $orm */
	public $orm;

	public function __construct(Orm $orm)
	{
		$this->orm = $orm;
	}

	/**
	 * @param int|null $organizationId
	 * @param bool $isAdmin
	 * @return Organization
	 */
	public function getOrganization($organizationId = null, $isAdmin = false)
	{
		if (isset($organizationId)) {
			$organizationID = $organizationId;
		} elseif (!$isAdmin) {
			/** @var UserAccount $userAccount */
			$userAccount = $this->orm->userAccounts->findBy(['isAdmin' => $isAdmin])->fetch();
			/** @var Position $userPosition */
			$userPosition = $this->orm->positions->findBy(['employee' => $userAccount->employee])->fetch();
			$organizationID = $userPosition->organization->id;
		} else {
			/** @var Organization $organization */
			$organization = $this->orm->organizations->findBy(['parentOrganization' => null])->fetch();
			if ($organization) {
				$organizationID = $organization->id;
			} else {
				$organizationID = null;
			}
		}
		
		return $this->orm->organizations->findById($organizationID)->fetch();
	}

}