<?php

namespace App\Model;

use Nette\InvalidArgumentException;
use Nette\Utils\DateTime;


class Calendar
{
	/**
	 * @param DateTime $monday
	 * @return array
	 */
	public function getWeek(DateTime $monday)
	{
		if ($monday->format('D') !== 'Mon')
			throw new InvalidArgumentException(__METHOD__ . " expecting datetime set on monday.");

		$startDateTime = clone $monday;
		$endDateTime = $this->getLastDayOfWeek($monday);
		$actualDT = $this->getCurrentDay();

		$weekOfYear = $monday->format("W");
		$tempDays = $this->getDays($startDateTime, $endDateTime, $actualDT);

		return $tempDays[$weekOfYear];
	}


	/**
	 * @param DateTime $monday
	 * @return DateTime
	 */
	public function getLastDayOfWeek(DateTime $monday)
	{
		if ($monday->format('D') !== 'Mon')
			throw new InvalidArgumentException(__METHOD__ . " expecting datetime set on monday.");

		return $monday->modifyClone('this week sunday');
	}


	/**
	 * @param int $year 2014, 2015...
	 * @param int $month 1, 2, 4, ... 12
	 * @return array
	 */
	public function getMonth($year, $month)
	{
		if (!$year)
			throw new InvalidArgumentException('$year argument is not nullable');
		if (!$month)
			throw new InvalidArgumentException('$month argument is not nullable');

		$startDateTime = $this->getFirstDayInMonth($year, $month);
		$endDateTime = $this->getLastDayInMonth($year, $month);
		$actualDT = $this->getCurrentDay();

		return $this->getDays($startDateTime, $endDateTime, $actualDT);
	}


	/**
	 * @param int $year 2014, 2015...
	 * @param int $month 1, 2, 4, ... 12
	 * @return DateTime
	 */
	public function getFirstDayInMonth($year, $month)
	{
		$selectedDateTime = new DateTime("$year-$month-1");
		$startDateTime = $selectedDateTime->modifyClone('monday this week');

		if ($startDateTime->format('d') != 1 && $startDateTime->format('m') == $selectedDateTime->format('m'))
			$startDateTime->modify('monday last week');

		return $startDateTime;
	}


	/**
	 * @param int $year 2014, 2015...
	 * @param int $month 1, 2, 4, ... 12
	 * @return DateTime
	 */
	public function getLastDayInMonth($year, $month)
	{
		$selectedDateTime = new DateTime("$year-$month-1");
		$endDateTime = $selectedDateTime->modifyClone('last day of this month');

		if ($endDateTime->format('D') != 'Sun')
			$endDateTime->modify('sunday this week');

		return $endDateTime;
	}


	/**
	 * @return DateTime
	 */
	public function getCurrentDay()
	{
		return new DateTime();
	}


	/**
	 * @param DateTime $startDate
	 * @param DateTime $endDate
	 * @param DateTime|NULL $currentDay
	 * @return array
	 */
	private function getDays(DateTime $startDate, DateTime $endDate, DateTime $currentDay = NULL)
	{
		$days = [];

		if (!$currentDay)
			$currentDay = $this->getCurrentDay();

		while ($startDate->getTimestamp() <= $endDate->getTimestamp()) {

			$weekOfYear = $startDate->format("W");
			$dateOfWeekShort = $startDate->format("D");

			$statusOfDay = $startDate->format('Y-m-d') == $currentDay->format('Y-m-d') ? "actualToday" : "notToday";

			$data = [
				'statusOfDay' => $statusOfDay,
				'weekOfYear' => $weekOfYear,
				'dateOfWeekShort' => $dateOfWeekShort,
				'date' => clone $startDate,
			];

			$days[$weekOfYear][$dateOfWeekShort] = $data;

			$startDate->modify('+ 1 day');
		}
		return $days;
	}

}