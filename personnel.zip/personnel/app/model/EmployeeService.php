<?php

namespace App\Model;


use App\Model\Persistence\Employees\Employee;
use App\Model\Persistence\JobTitles\JobTitle;
use App\Model\Persistence\Organizations\Organization;
use App\Model\Persistence\Orm;
use App\Model\Persistence\Positions\Position;
use App\Model\Persistence\UserAccounts\UserAccount;
use Nextras\Dbal\InvalidArgumentException;

class EmployeeService
{
	/** @var Orm $orm */
	public $orm;

	/**
	 * EmployeeService constructor.
	 * @param Orm $orm
	 */
	public function __construct(Orm $orm)
	{
		$this->orm = $orm;
	}

	/**
	 * @param $newEmployeeID
	 * @return array
	 */
	public function getNewUserKeyAndUserInfo($newEmployeeID)
	{
		$employee = $this->orm->employees->getById($newEmployeeID);
		$employeeCheck = $this->orm->userAccounts->findBy(['employee' => $newEmployeeID])->fetch();

		$userKey = null;
		$newPosition = null;

		if (!$employee) {
			throw new InvalidArgumentException('Employee not exist!');
		} elseif ($employeeCheck && $employeeCheck->getValue('isActive')) {
			throw new InvalidArgumentException('Employee was already active');
		} elseif ($employeeCheck && !$employeeCheck->getValue('isActive')) {
			$userAccount = $this->orm->userAccounts->findBy(['employee' => $newEmployeeID])->fetch();
			$userKey = $userAccount->getValue('newcomerKey');
			$newPosition = $this->orm->positions->findBy(['employee' => $newEmployeeID])->fetchAll();
		} else {
			$userAccount = new UserAccount($employee);
			$this->orm->persistAndFlush($userAccount);
			$userKey = $userAccount->newcomerKey;
			$newPosition = $this->orm->positions->findBy(['employee' => $newEmployeeID])->fetchAll();
		}

		return [$userKey, $newPosition];
	}

	/**
	 * @param int $employeeId
	 * @param $passwords
	 */
	public function changePassword($employeeId, $passwords)
	{
		/** @var UserAccount $userAccount */
		$userAccount = $this->orm->userAccounts->findBy(['employee' => $employeeId])->fetch();
		if (!$userAccount->verifyPassword($passwords->originPassword)) {
			throw new InvalidArgumentException('Origin password wrong');
		} elseif ($passwords->newPassword != $passwords->confirmNewPassword) {
			throw new InvalidArgumentException('New password not equal confirm password');
		} else {
			$userAccount->changePassword($passwords->newPassword);
			$this->orm->persistAndFlush($userAccount);
		}
	}

	/**
	 * @param int $employeeId
	 * @param string $password reset password
	 */
	public function resetPassword($employeeId, $password)
	{
		/** @var UserAccount $userAccount */
		$userAccount = $this->orm->userAccounts->findBy(['employee' => $employeeId])->fetch();

		$userAccount->changePassword($password);
		$this->orm->persistAndFlush($userAccount);
	}

	/**
	 * @param int $employeeId
	 * @param int $loggedUserId
	 * @return bool delete employee success or not
	 */
	public function deleteEmployee($employeeId, $loggedUserId)
	{
		$employeePersonalInfo = null;
		$person = null;

		if ($userAccount = $this->orm->userAccounts->getBy(['employee' => $employeeId])) {
			if ($userAccount->id == $loggedUserId) {
				return false;
			}
		}
		if ($position = $this->orm->positions->getBy(['employee' => $employeeId])) {
		}
		if ($employee = $this->orm->employees->getBy(['id' => $employeeId])) {
			if ($employee->personalInfo) {
				$employeePersonalInfo = $employee->personalInfo->id;
			}
		}
		if ($employeePersonalInfo && $person = $this->orm->persons->getBy(['id' => $employeePersonalInfo])) {
		}

		if ($userAccount)
			$this->orm->userAccounts->removeAndFlush($userAccount, true);
		if ($position)
			$this->orm->positions->removeAndFlush($position, true);
		if ($employee)
			$this->orm->employees->removeAndFlush($employee, true);
		if ($person)
			$this->orm->persons->removeAndFlush($person, true);

		return true;
	}


	public function saveEmployeeInfo(Employee $employee, $values)
	{
		$employee->firstName = $values['firstName'];
		$employee->lastName = $values['lastName'];
		$employee->employeeNumber = $values['employeeNumber'];
		$employee->dateOfHire = $values['dateOfHire'];
		$employee->personalEmail = $values['personalEmail'];
		$this->orm->persistAndFlush($employee);
	}

	public function saveEmployeePosition(array $positionValues, Position $position)
	{
		$position->employee = $positionValues['employee'];
		$position->organization = $positionValues['organization'];
		$position->jobTitle = $positionValues['jobTitle'];
		$position->isDirector = $positionValues['isDirector'];
		$this->orm->persistAndFlush($position);
	}

	/**
	 * @param array|Position $positions
	 * @return array
	 */
	public function transferPositionsToArray($positions)
	{
		$position = [];
		for ($i = 0; $i < count($positions); $i++) {
			$position[$i] = [
				'organization' => $positions[$i]->organization,
				'jobTitle' => $positions[$i]->jobTitle,
				'isDirector' => $positions[$i]->isDirector,
			];
		}
		return $position;
	}

}