<?php

require __DIR__ . '/../vendor/autoload.php';

$configurator = new Nette\Configurator;

//$configurator->setDebugMode('23.75.345.200'); // enable for your remote IP
$configurator->enableDebugger(__DIR__ . '/../log');

$configurator->setTempDirectory(__DIR__ . '/../temp');

$configurator->createRobotLoader()
	->addDirectory(__DIR__)
	->register();

$configurator->addConfig(__DIR__ . '/config/config.neon');
$configurator->addConfig(__DIR__ . '/config/config.local.neon');
$configurator->addConfig(__DIR__ . '/config/ext/extensions.neon');

$container = $configurator->createContainer();

/**
 * Debug variable to tracy debug bar.
 *
 * @param mixed $var
 * @param int $maxDepth
 * @return mixed
 */
function dd($var, $maxDepth = 3)
{
	\Tracy\Debugger::$maxDepth = $maxDepth;

	$b = debug_backtrace();
	$split = explode('\\', $b[0]['file']);
	end($split);
	$file = $split[key($split)];
	$line = $b[0]['line'];

	$title = $file . ' : ' . $line;
	\Tracy\Debugger::barDump($var, $title);

	return $var;
}

return $container;
