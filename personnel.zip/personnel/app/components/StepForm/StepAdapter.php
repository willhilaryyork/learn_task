<?php

namespace App\Components\StepForm;

use Nette\Application\UI\Control;
use Nette\Application\UI\Form;
use Nette\ComponentModel\IContainer;


class StepAdapter extends Control
{
	/**
	 * @var IContainer
	 */
	private $form;

	/**
	 * @var string
	 */
	private $templateFile;


	/**
	 * <b>Usage in Presenter</b> <br>
	 * StepAdapter is for conversion of your Presenter Form into Step Form component.
	 * Your factory method for your form (YourPresenter::createComponentFormName) has to return this adapter instead of
	 * simple form if you want to using it inside App\Components\StepForm\StepFormControl <br><br>
	 *
	 * <b>Initialize:</b> <br>
	 * App\Component\StepAdapter(Nette\Application\UI\Form, 'templates/Your/form1.latte')
	 *
	 * @param Form $form
	 * @param string $template Latte file path
	 */
	public function __construct(Form $form, $template = null)
	{
		$this->form = $form;
		$this->templateFile = $template;
	}


	protected function attached($presenter)
	{
		parent::attached($presenter);
		$this->addComponent($this->form, $this->getName());
	}


	public function render()
	{
		$this->template->form = $this->form;
		$this->template->setFile(is_string($this->templateFile) ? $this->templateFile : __DIR__ . '/templates/renderer.latte');
		$this->template->render();
	}

}