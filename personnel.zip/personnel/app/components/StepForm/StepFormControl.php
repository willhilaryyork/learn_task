<?php

namespace App\Components\StepForm;

use Nette\Application\UI\Control;
use Nette\Application\UI\Presenter;
use Nette\Application\UI\PresenterComponent;


class StepFormControl extends Control
{
	/**
	 * @var array
	 */
	private $steps;

	/**
	 * @var array
	 */
	private $menu;

	/**
	 * @var string|int
	 */
	private $position;

	/**
	 * @var string
	 */
	private $templateFile;


	/**
	 * <b>Usage in Presenter</b> <br>
	 * For expected Nette\Application\UI\PresenterComponent you need to return from your factory method
	 * App\Components\StepForm\StepAdapter, or you can implement your own Nette\Application\UI\Control.
	 * <br><br>
	 *
	 * App\Components\StepFormControl::addStep('Step 1', App\Presenters\YourPresenter::getComponent('form1')) <br>
	 * App\Components\StepFormControl::addStep('Step 2', App\Presenters\YourPresenter::getComponent('form2'))
	 *
	 * @param string $linkName
	 * @param PresenterComponent $component
	 * @param string|int|NULL $stepKey default [1, 2, 3, ...]
	 */
	public function addStep($linkName, PresenterComponent $component, $stepKey = NULL)
	{
		if (!$component->getParent() instanceof Presenter) {
			throw new \LogicException('You need to attache ' . get_class($component) . ' into ' . Presenter::class .
				' before using ' . __METHOD__ . '. Please use ' . Presenter::class . '::getComponent');
		}

		if ($stepKey !== NULL) {
			$counter = $stepKey;
			if (isset($this->menu[$counter]))
				throw new \LogicException("StepKey '$stepKey'' already exist.");

		} else {
			$counter = count($this->menu) + 1;
		}

		$this->menu[$counter] = $linkName;
		$this->steps[$counter] = $component;
	}


	/**
	 * @param Presenter $presenter
	 */
	protected function attached($presenter)
	{
		parent::attached($presenter);
		$this->position = $this->getPresenter()->getParameter('step') ?
			$this->getPresenter()->getParameter('step') :
			array_keys($this->menu)[0];
	}


	/**
	 * <b>Template will receive following variables:</b><br>
	 * array <b>$menu</b>::[int urlKey => string stepName] Information for render menu items<br>
	 * int <b>$position</b> Current position in step form<br>
	 * array <b>$steps</b>::[int positionKey => PresenterComponent $form] array of all forms added by addStep method<br>
	 * <br>
	 * <b>For simple usage of your custom template use predefined HTML variables:</b><br>
	 * Latte <b>$menuFieldsHTML</b> Contain HTML of &lt;li&gt; for menu of all your steps<br>
	 * Latte <b>$stepFormHTML</b> Contain current step form<br>
	 * <br>
	 * Use <b>include</b> macro for render HTML blocks:<br>
	 * <b>{include $menuFieldsHTML class => 'your own classes'}</b> optionally you can add
	 * your own classes for each &lt;li&gt;<br>
	 * <b>{include $stepFormHTML}</b>
	 *
	 * @param string $template
	 */
	public function setCustomTemplate($template)
	{
		$this->templateFile = $template;
	}


	public function render()
	{
		$this->template->setFile(
			is_string($this->templateFile) ?
				$this->templateFile :
				__DIR__ . '/templates/defaultStepForm.latte'
		);

		$this->template->steps = $this->steps;
		$this->template->menu = $this->menu;
		$this->template->position = $this->position;

		$this->template->menuFieldsHTML = __DIR__ . '/templates/menuFields.latte';
		$this->template->stepFormHTML = __DIR__ . '/templates/step.latte';

		$this->template->render();
	}


	/**
	 * @return string|int
	 */
	public function getCurrentStepKey()
	{
		return $this->position;
	}


	/**
	 * @param $stepKey
	 */
	public function jump($stepKey)
	{
		$this->presenter->redirect('this', ['step' => $stepKey]);
	}

}