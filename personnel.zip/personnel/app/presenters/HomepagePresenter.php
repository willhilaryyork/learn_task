<?php

namespace App\Presenters;


use App\Model\Calendar;
use Latte\Engine;
use Nette\Application\UI\Form;
use Nette\Caching\Cache;
use Nette\Caching\Storages\FileStorage;
use Nette\Forms\Controls\Button;
use Nette\Mail\IMailer;
use Nette\Mail\Message;
use Nette\Utils\DateTime;
use Nette\Utils\Validators;

class HomepagePresenter extends BasePresenter
{
	/**
	 * @var Calendar $calendar @inject
	 */
	public $calendar;

	/**
	 * @var IMailer @inject
	 */
	public $mailer;

	public function beforeRender()
	{
		if (!$this->getUser()->isLoggedIn())
			$this->redirect('Sign:in');

		$this->template->realDateTime = $this->calendar->getCurrentDay();
	}

	public function renderDefault()
	{
		//$this->redirect('Homepage:Week');
	}

	public function createComponentSendEmailForm()
	{
		$form = new Form();

		$form->addText('eMailTo', 'EMail To')->setRequired();
		$form->addSubmit('send', 'Send')->onClick[] = array($this, 'inviteEmployeeMailSuccess');

		return $form;
	}

	public function validateEMailFormat(array $emails)
	{
		foreach ($emails as $email) {
			if (!Validators::isEmail($email) && $email) {
				$this->flashMessage('EMail "' . $email . '" format error, please check!', 'flash-error');
				return false;
			}
		}
		return true;
	}

	public function sendEMail($email)
	{
		$targetPath = $this->handleGenerateKey();
		$latte = new Engine();
		$params = [
			'targetPath' => $targetPath,
		];
		$path = __DIR__ . '/emailTemplate.latte';

		$emailContent = $latte->renderToString($path, $params);

		$mail = new Message();
		$mail->setFrom('system@personnel.com');
		$mail->addTo($email);
		$mail->setSubject('Invite Register Link');
		$mail->setHtmlBody($emailContent);

		$this->mailer->send($mail);
	}

	public function inviteEmployeeMailSuccess(Button $button)
	{
		$values = $button->getForm()->getValues();
		$emails = array_values(array_unique(array_diff(explode(';', $values->eMailTo), array(""))));
		$correctEmailAddress = $this->validateEMailFormat($emails);

		if ($correctEmailAddress) {
			foreach ($emails as $email)
				$this->sendEMail($email);

			$this->flashMessage('EMail send success!', 'flash-info');
			$this->redirect('Homepage:default');
		}
	}

	public function handleGenerateKey()
	{
		$key = uniqid('TEST', true);
		$data = [
			'mail' => 'test@example.com',
			'name' => 'sir vip',
		];
		$storage = new FileStorage('../temp');
		$cache = new Cache($storage, 'htmlOutput');
		$cache->save($key, $data, [
			Cache::EXPIRE => '20 minutes', // accepts also seconds or a timestamp.
		]);

		return $this->template->baseUrl . '/employee-register/invite-employee-register/?str=' . $key;
	}

	public function renderWeek($thisWeekOneDay, $employeeID)
	{
		if ($thisWeekOneDay)
			$monday = new DateTime($thisWeekOneDay);
		else
			$monday = new DateTime('this week monday');

		$weekDays = $this->calendar->getWeek($monday);

		//$startDateTime = clone $monday;
		//$endDateTime = $this->calendar->getLastDayOfWeek($monday);

		$this->template->displayDateTime = $monday;
		$this->template->showBy = 'week';

		$this->template->weekDays = $weekDays;
		$this->template->dayPeriods = ['Morning', 'Afternoon', 'Night'];

	}

	public function renderMonth($year, $month, $employeeID)
	{
		if (!$year)
			$year = date('Y');
		if (!$month)
			$month = date('n');

		$monthDays = $this->calendar->getMonth($year, $month);

		//$startDateTime = $this->calendar->getFirstDayInMonth($year, $month);
		//$endDateTime = $this->calendar->getLastDayInMonth($year, $month);

		$this->template->displayDateTime = new DateTime("$year-$month-1");
		$this->template->showBy = 'month';

		$this->template->days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
		$this->template->monthDays = $monthDays;

	}

	public function renderDay($oneDay, $employeeID)
	{
		if ($oneDay)
			$selectedDay = new DateTime($oneDay);
		else {
			$currentTime = new DateTime();
			$selectedDay = new DateTime($currentTime->format('Y-m-d'));
		}

		if ($selectedDay->format('D') !== 'Mon')
			$monday = $selectedDay->modifyClone('last monday');
		else
			$monday = clone $selectedDay;

		$weekDays = $this->calendar->getWeek($monday);

		$dateString = $selectedDay->format("m/d");
		$weekOfYear = $selectedDay->format("W");
		$dateOfWeek = $selectedDay->format("l"); // D: 'Mon'  l(Lower case of L): 'Sunday'

		$dayInfo = [
			'weekOfYear' => $weekOfYear,
			'dateOfMonth' => $dateString,
			'dateOfWeek' => $dateOfWeek,
		];

		$this->template->displayDateTime = $selectedDay;
		$this->template->showBy = 'day';

		$this->template->weekDays = $weekDays;
		$this->template->dayInfos = $dayInfo;

	}

}
