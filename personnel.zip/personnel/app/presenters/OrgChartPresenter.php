<?php

namespace App\Presenters;


use App\Model\EmployeeService;
use App\Model\OrgChart;
use App\Model\Persistence\Organizations\Organization;
use App\Model\Persistence\Orm;

class OrgChartPresenter extends BasePresenter
{
	/** @var Orm @inject */
	public $orm;
	/** @var OrgChart @inject */
	public $orgChart;
	/**  @var EmployeeService $employeeService @inject */
	public $employeeService;

	private $employeeId;

	public function beforeRender()
	{
		if (!$this->getUser()->isLoggedIn())
			$this->redirect('Sign:in');
	}

	public function renderDefault($organizationId)
	{
		/** @var Organization $organization */
		$organization = $this->orgChart->getOrganization($organizationId, $this->user->getIdentity()->isAdmin);
		if (!$organization) {
			$this->flashMessage('Organization not found!', 'flash-info');
			$this->redirect('OrgChart:wholeOrgChart');
		}
		$this->template->organizations = $organization;
	}

	public function renderWholeOrgChart()
	{
		/** @var Organization $organizations */
		$organizations = $this->orm->organizations->findBy(['parentOrganization' => null])->fetch();
		$this->template->organizations = $organizations;
	}

	public function renderEmployeeDetail()
	{
		$positions = $this->orm->positions->findBy(['employee' => $this->employeeId])->fetchAll();
		if (!$positions) {
			$this->flashMessage('Employee not found!', 'flash-info');
			$this->redirect('OrgChart:default');
		}

		$employee = $positions[0]->employee;

		$this->template->employee = $employee;
		$this->template->position = $this->employeeService->transferPositionsToArray($positions);
	}

	public function actionEmployeeDetail($employeeId)
	{
		$this->employeeId = $employeeId;
	}
}