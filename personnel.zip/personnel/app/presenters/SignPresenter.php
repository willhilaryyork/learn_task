<?php

namespace App\Presenters;

use Nette;


class SignPresenter extends BasePresenter
{

	/**
	 * @return Nette\Application\UI\Form
	 */
	protected function createComponentSignInForm()
	{
		$form = new Nette\Application\UI\Form;
		$form->addText('username', 'Username:')
			->setRequired('Please enter your username.');

		$form->addPassword('password', 'Password:')
			->setRequired('Please enter your password.');

		$form->addSubmit('send', 'Sign in');

		$form->onSuccess[] = array($this, 'signInFormSucceeded');
		return $form;
	}

	public function signInFormSucceeded(Nette\Application\UI\Form $form, $values)
	{
		try {
			$this->user->login($values->username, $values->password);
			$this->flashMessage('Log in success!', 'flash-info');
			$this->redirect('Homepage:default');

		} catch (Nette\Security\AuthenticationException $e) {
			//$form->addError($e->getMessage());
			$this->flashMessage($e->getMessage(), 'flash-error');
		}
	}

	/**
	 * user log out
	 */
	public function actionOut()
	{
		$this->getUser()->logout();
		$this->redirect('Homepage:default');
	}

}
