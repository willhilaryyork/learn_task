<?php

namespace App\Presenters;

use App\Model\Persistence\JobTitles\JobTitle;
use App\Model\Persistence\Orm;
use App\Model\Persistence\Responsibilities\Responsibility;
use Latte\Engine;
use Nette\Application\UI\Form;
use Nextras\Dbal\ForeignKeyConstraintViolationException;
use Nextras\Dbal\UniqueConstraintViolationException;
use App\Model\OrgChart;
use App\Model\Persistence\Organizations\Organization;
use App\Model\Persistence\OrganizationTypes\OrganizationType;
use Nextras\Orm\InvalidStateException;

class SystemSettingPresenter extends BasePresenter
{
	/**
	 * @var Orm @inject
	 */
	public $orm;

	/**
	 * @var  OrgChart @inject
	 */
	public $orgChart;

	public function beforeRender()
	{
		if (!$this->getUser()->isLoggedIn())
			$this->redirect('Sign:in');
	}

	public function renderDefault()
	{
		$responsibilities = $this->orm->responsibilities->findAll()->fetchAll();
		$jobTitles = $this->orm->jobTitles->findAll()->fetchAll();
		$this->template->responsibilities = $responsibilities;
		$this->template->jobTitles = $jobTitles;
	}

	public function handleAddResponsibility()
	{
		$this->getSession('responsibility')->remove();
	}

	public function handleEditResponsibility($responsibilityId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}
		$section = $this->getSession('responsibility');
		$section->responsibilityId = $responsibilityId;

		$responsibility = $this->orm->responsibilities->getById($responsibilityId);
		if (!$responsibility) {
			$this->error('Responsibility not found');
		}

		$this['addResponsibilityForm']->setDefaults(['responsibilityName' => $responsibility->name]);
		$this->redrawControl('editResponsibilityForm');
	}

	public function createComponentAddResponsibilityForm()
	{
		$form = new Form();
		$form->addText('responsibilityName', 'Responsibility Name')->setRequired();
		$form->addSubmit('save', 'Save');
		$form->onSuccess[] = [$this, 'addResponsibilitySucceeded'];

		return $form;
	}

	public function addResponsibilitySucceeded($form, $values)
	{

		if ($this->getSession('responsibility')->responsibilityId) {
			$newResponsibility = $this->orm->responsibilities->getById($this->getSession('responsibility')->responsibilityId);
			$this->getSession('responsibility')->remove();
		} else {
			$newResponsibility = new Responsibility();
		}
		$newResponsibility->name = $values->responsibilityName;

		try {
			$this->orm->persistAndFlush($newResponsibility);
			$this->redirect("SystemSetting:default");
		} catch (UniqueConstraintViolationException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');
		}
	}

	public function handleDeleteResponsibility($responsibilityId)
	{
		/** @var Responsibility $responsibility */
		$responsibility = $this->orm->responsibilities->findById($responsibilityId)->fetch();

		try {
			$this->orm->responsibilities->removeAndFlush($responsibility);
		} catch (ForeignKeyConstraintViolationException $e) {
			$this->flashMessage('The "' . $responsibility->name . '" is in use, not allowed to delete', 'flash-error');
		}
		$this->redirect("SystemSetting:default");

	}

	public function handleAddJobTitle()
	{
		$this->getSession('jobTitle')->remove();
	}

	public function handleEditJobTitle($jobTitleId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}
		$section = $this->getSession('jobTitle');
		$section->jobTitleId = $jobTitleId;

		$jobTitle = $this->orm->jobTitles->getById($jobTitleId);
		if (!$jobTitle) {
			$this->error('Job Title not found');
		}

		$this['addJobTitleForm']->setDefaults([
			'jobTitleName' => $jobTitle->name,
			'jobTitleDescription' => $jobTitle->description,
		]);

		$this->redrawControl('editJobTitleForm');
	}

	public function createComponentAddJobTitleForm()
	{
		$form = new Form();
		$form->addText('jobTitleName', 'Job Title Name')->setRequired();
		$form->addText('jobTitleDescription', 'Job Title Description');
		$form->addSubmit('save', 'Save');
		$form->onSuccess[] = [$this, 'addJobTitleSucceeded'];

		return $form;
	}

	public function addJobTitleSucceeded($form, $values)
	{
		if ($this->getSession('jobTitle')->jobTitleId) {
			$newJobTitle = $this->orm->jobTitles->getById($this->getSession('jobTitle')->jobTitleId);
			$this->getSession('jobTitle')->remove();
		} else {
			$newJobTitle = new JobTitle();
		}
		$newJobTitle->name = $values->jobTitleName;
		$newJobTitle->description = $values->jobTitleDescription;

		try {
			$this->orm->persistAndFlush($newJobTitle);
			$this->redirect("SystemSetting:default");
		} catch (UniqueConstraintViolationException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');
		}
	}

	public function handleDeleteJobTitle($jobTitleId)
	{
		/** @var JobTitle $jobTitle */
		$jobTitle = $this->orm->jobTitles->findById($jobTitleId)->fetch();

		try {
			$this->orm->jobTitles->removeAndFlush($jobTitle);
		} catch (ForeignKeyConstraintViolationException $e) {
			$this->flashMessage('The "' . $jobTitle->name . '" is in use, not allowed to delete', 'flash-error');
		}
		$this->redirect("SystemSetting:default");
	}

	public function renderOrgManagement()
	{
		$organizationTypes = $this->orm->organizationTypes->findAll()->fetchAll();
		$organizations = $this->orm->organizations->findAll()->fetchAll();

		$this->template->organizationTypes = $organizationTypes;
		$this->template->organizations = $organizations;
	}

	public function handleDeleteOrgType($organizationTypeId)
	{
		/** @var OrganizationType $organizationType */
		$organizationType = $this->orm->organizationTypes->findById($organizationTypeId)->fetch();

		try {
			$this->orm->organizationTypes->removeAndFlush($organizationType);
		} catch (ForeignKeyConstraintViolationException $e) {
			$this->flashMessage('The "' . $organizationType->name . '" is in use, not allowed to delete!', 'flash-error');
		}
		$this->redirect("SystemSetting:orgManagement");
	}

	public function handleDeleteOrg($organizationId)
	{
		/** @var Organization $organization */
		$organization = $this->orm->organizations->findById($organizationId)->fetch();

		try {
			$this->orm->organizations->removeAndFlush($organization);
		} catch (InvalidStateException $e) {
			$this->flashMessage('The "' . $organization->name . '" is in use, not allowed to delete!', 'flash-error');
		}
		$this->redirect("SystemSetting:orgManagement");
	}

	public function handleAddOrganizationType()
	{
		$this->getSession('organizationType')->remove();
	}

	public function handleEditOrganizationType($organizationTypeId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}
		$section = $this->getSession('organizationType');
		$section->organizationTypeId = $organizationTypeId;

		$organizationType = $this->orm->organizationTypes->getById($organizationTypeId);
		if (!$organizationType) {
			$this->error('Organization Type not found');
		}

		$this['addOrganizationTypeForm']->setDefaults(['organizationTypeName' => $organizationType->name]);
		$this->redrawControl('editOrganizationTypeForm');
	}

	public function createComponentAddOrganizationTypeForm()
	{
		$form = new Form();
		$form->addText('organizationTypeName', 'Organization Name')->setRequired();
		$form->addSubmit('save', 'Save');
		$form->onSuccess[] = [$this, 'addOrganizationTypeSucceeded'];

		return $form;
	}

	public function addOrganizationTypeSucceeded($form, $values)
	{
		if ($this->getSession('organizationType')->organizationTypeId) {
			$newOrganizationType = $this->orm->organizationTypes->getById($this->getSession('organizationType')->organizationTypeId);
			$this->getSession('organizationType')->remove();
		} else {
			$newOrganizationType = new OrganizationType();
		}
		$newOrganizationType->name = $values->organizationTypeName;
		try {
			$this->orm->persistAndFlush($newOrganizationType);
			$this->redirect("SystemSetting:orgManagement");
		} catch (UniqueConstraintViolationException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');
		}
	}

	public function handleAddOrganization()
	{
		$this->getSession('organization')->remove();
	}

	public function handleEditOrganization($organizationId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}
		$section = $this->getSession('organization');
		$section->organizationId = $organizationId;

		$organization = $this->orm->organizations->getById($organizationId);
		if (!$organization) {
			$this->error('Organization not found');
		}
		$this['addOrganizationForm']->setDefaults(
			[
				'organizationName' => $organization->name,
				'parentOrganization' => isset($organization->parentOrganization->id) ? $organization->parentOrganization->id : null,
				'organizationType' => $organization->type->id,
			]);
		$this->redrawControl('editOrganizationForm');
	}

	public function createComponentAddOrganizationForm()
	{
		$organizations = $this->orm->organizations->findAll()->fetchPairs('id', 'name');
		$organizations[0] = null;
		ksort($organizations);
		$organizationTypes = $this->orm->organizationTypes->findAll()->fetchPairs('id', 'name');

		$form = new Form();
		$form->addText('organizationName', 'Organization Name')->setRequired();
		$form->addSelect('parentOrganization', 'Parent Organization', $organizations);
		$form->addSelect('organizationType', 'Organization Type', $organizationTypes)->setRequired();
		$form->addSubmit('save', 'Save');
		$form->onSuccess[] = [$this, 'addOrganizationSucceeded'];

		return $form;
	}

	public function addOrganizationSucceeded($form, $values)
	{
		if ($this->getSession('organization')->organizationId) {
			$newOrganization = $this->orm->organizations->getById($this->getSession('organization')->organizationId);
			$this->getSession('organization')->remove();
		} else {
			$newOrganization = new Organization();
		}

		$newOrganization->name = $values->organizationName;
		$newOrganization->parentOrganization = $this->orm->organizations->getById($values->parentOrganization);
		$newOrganization->type = $this->orm->organizationTypes->getById($values->organizationType);

		try {
			$this->orm->persistAndFlush($newOrganization);
			$this->redirect("SystemSetting:orgManagement");
		} catch (UniqueConstraintViolationException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');
		}
	}

	public function createComponentEMailTemplate()
	{
		$form = new Form();
		$form->addTextArea('eMailContent', 'Mail Content', null, 8)->setAttribute('class', 'wysihtml5Editor');
		$form->addSubmit('save', 'Save');
		$form->onSuccess[] = array($this, 'editTemplateSuccess');

		return $form;
	}

	public function editTemplateSuccess($form, $values)
	{
		$path = __DIR__ . '/emailTemplate.latte';
		$content = $values['eMailContent'];
		file_put_contents($path, $content);
		$this->flashMessage('EMail Template modify success!', 'flash-info');
	}

	public function actionEditEmailTemplate($reset = false)
	{
		$targetPath = '{$targetPath}';
		$latte = new Engine();
		$params = [
			'targetPath' => $targetPath,
		];
		$path = __DIR__ . '/emailTemplate.latte';

		$emailContent = $latte->renderToString($path, $params);

		if ($reset)
			$emailContent = "<p>Hello,</p>
<p>Welcome to Personnel, click the link below to complete your profile and register your account, thank you!</p>
<p><b><a target=\"_blank\" href=\"{$targetPath}\">click here to register</a></b></p>
<i>This e-mail is sent by Personal system automatically.</i>
<br>
<i>Please do not reply directly.</i>";

		$this['eMailTemplate']->setDefaults(['eMailContent' => $emailContent]);
	}

}