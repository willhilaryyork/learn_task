<?php

namespace App\Presenters;

use App\Components\StepForm\StepAdapter;
use App\Components\StepForm\StepFormControl;
use App\Model\Persistence\Employees\Employee;
use App\Model\Persistence\Orm;
use App\Model\Persistence\Persons\Person;
use App\Model\Persistence\Positions\Position;
use App\Model\Persistence\UserAccounts\UserAccount;
use App\Model\Register;
use App\Model\SessionService;
use Nette\Application\UI\Form;
use Nette\Caching\Cache;
use Nette\Caching\Storages\FileStorage;
use Nette\Forms\Controls\Button;
use Nette\InvalidArgumentException;
use Nette\Security\AuthenticationException;
use Nette\Security\Passwords;
use Nextras\Dbal\UniqueConstraintViolationException;

class EmployeeRegisterPresenter extends BasePresenter
{
	/** @var  Orm $orm @inject */
	public $orm;
	/** @var  Register $register @inject */
	public $register;
	/** @var  SessionService $sessionService @inject */
	public $sessionService;

	private $genderList = [
		'GENDER_MALE' => 'Male',
		'GENDER_FEMALE' => 'Female',
	];

	private $maritalStatusList = [
		'MARITAL_STATUS_SINGLE' => 'Single',
		'MARITAL_STATUS_MARRIED' => 'Married',
		'MARITAL_STATUS_DIVORCED' => 'Divorced',
		'MARITAL_STATUS_WIDOWED' => 'Widowed',
		'MARITAL_STATUS_LIVING_COMMON_LAW' => 'Living common law',
		'MARITAL_STATUS_SEPARATED' => 'Separated',
	];

	private $uniqueCode;

	public function createComponentStepForm()
	{
		$control = new StepFormControl();
		$control->setCustomTemplate(__DIR__ . '/templates/EmployeeRegister/stepForm/form.latte');

		$employeeForm = $this->getComponent('addCurrentEmployeeForm');
		$employeeForm->template->employeeInfo = $this->getSession('employeeInfo');
		$control->addStep('Enter Basic Info', $employeeForm, 'employeeInfo');

		$personalForm = $this->getComponent('addPersonalInfoForm');
		$personalForm->template->personalInfo = $this->getSession('personalInfo');
		$control->addStep('Enter Personal Info', $personalForm, 'personalInfo');

		$confirmInfo = $this->getComponent('confirmInfoForm');
		$confirmInfo->template->employeeInfo = $this->getSession('employeeInfo');
		$confirmInfo->template->personalInfo = $this->getSession('personalInfo');
		$confirmInfo->template->jobTitles = $this->orm->jobTitles->findAll()->fetchPairs('id', 'name');
		$confirmInfo->template->organizations = $this->orm->organizations->findAll()->fetchPairs('id', 'name');
		$confirmInfo->template->genderList = $this->genderList;
		$confirmInfo->template->maritalStatusList = $this->maritalStatusList;
		$control->addStep('Confirm All Info', $confirmInfo, 'confirmInfo');

		$control->addStep('Register', $this->getComponent('registerForm'), 'registerStep');

		return $control;
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentAddCurrentEmployeeForm()
	{
		$jobTitleLists = $this->orm->jobTitles->findAll()->fetchPairs('id', 'name');
		$organizationLists = $this->orm->organizations->findAll()->fetchPairs('id', 'name');

		$form = new Form();
		$form->addText('firstName', 'First Name')->setRequired();
		$form->addText('lastName', 'Last Name')->setRequired();
		$form->addText('employeeNumber', 'Employee Number')->setRequired();
		$form->addText('personalEmail', 'Personal Email');
		$form->addText('dateOfHire', 'Date Of Hire')->setRequired();
		$form->addSelect('jobTitle', 'Job Title', $jobTitleLists);
		$form->addSelect('organization', 'Organization', $organizationLists);
		$form->addSubmit('nextToPersonalInfo', 'Next');
		$form->onSuccess[] = array($this, 'addCurrentEmployeeSucceeded');

		$section = $this->getSession('employeeInfo');
		$section->setExpiration(0);
		$form->setDefaults($section);

		return new StepAdapter($form, __DIR__ . '/templates/EmployeeRegister/stepForm/employeeInfoForm.latte');
	}

	public function addCurrentEmployeeSucceeded(Form $form, $values)
	{
		$section = $this->getSession('employeeInfo');
		$this->sessionService->arrayToSection($section, $values);

		/** @var Employee $employee */
		$employee = $this->orm->employees->findBy(['employeeNumber' => $this->getSession('employeeInfo')->employeeNumber])->fetch();
		if ($employee) {
			/** @var UserAccount $userAccount */
			$userAccount = $this->orm->userAccounts->findBy(['employee' => $employee->id])->fetch();
		}
		if (isset($employee) && !isset($userAccount) && !$employee->personalInfo) {
			$this->flashMessage('This employee not allowed to register', 'flash-info');
			$this['stepForm']->jump('employeeInfo');
		} elseif (isset($userAccount) && $userAccount->newcomerKey) {
			$this->flashMessage('Please use your new comer key register', 'flash-info');
			$this->redirect('Register:default');
		} elseif (isset($userAccount) && !$userAccount->newcomerKey) {
			$this->flashMessage('This employee number had account, please change another employee number', 'flash-info');
			$this['stepForm']->jump('employeeInfo');
		} else {
			$this['stepForm']->jump('personalInfo');
		}
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentAddPersonalInfoForm()
	{
		$form = new Form();
		$form->addText('dateOfBirth', 'Birth Day')->setRequired();
		$form->addText('placeOfBirth', 'Birth Place')->setRequired();
		$form->addSelect('gender', 'Gender', $this->genderList)->setRequired();
		$form->addSelect('maritalStatus', 'Marital Status', $this->maritalStatusList)->setRequired();
		$form->addText('nationality', 'Nationality')->setRequired();
		$form->addText('permanentStay', 'Permanent Stay')->setRequired();
		$form->addText('personalIdentityNumber', 'ID Number')->setRequired();
		$form->addText('personalPhoneNumber', 'Personal Phone Number')->setRequired();
		$form->addSubmit('backToEmployeeInfo', 'Previous')->setValidationScope(false)->onClick[] = array($this, 'previousToEmployeeInfo');
		$form->addSubmit('nextToRegister', 'Next')->onClick[] = array($this, 'addPersonalInfoSucceeded');

		$section = $this->getSession('personalInfo');
		$section->setExpiration(0);
		$form->setDefaults($section);

		return new StepAdapter($form, __DIR__ . '/templates/EmployeeRegister/stepForm/personalInfoForm.latte');
	}

	public function previousToEmployeeInfo()
	{
		$this['stepForm']->jump('employeeInfo');
	}

	public function addPersonalInfoSucceeded(Button $button)
	{
		$values = $button->getForm()->getValues();
		$section = $this->getSession('personalInfo');
		$this->sessionService->arrayToSection($section, $values);

		/** @var Person $person */
		$person = $this->orm->persons->findBy(['personalIdentityNumber' => $values->personalIdentityNumber])->fetch();

		if ($person) {
			/** @var Employee $employee */
			$employee = $this->orm->employees->findBy(['personalInfo' => $person->id])->fetch();
			if ($employee->employeeNumber != $this->getSession('employeeInfo')->employeeNumber) {
				$this->flashMessage('Personal identity number duplicate', 'flash-error');
				$this['stepForm']->jump('personalInfo');
			} else {
				$this['stepForm']->jump('confirmInfo');
			}
		} else {
			$this['stepForm']->jump('confirmInfo');
		}
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentConfirmInfoForm()
	{
		$form = new Form();

		$form->addSubmit('backToPersonalInfo', 'Previous')->onClick[] = array($this, 'previousToPersonalInfo');
		$form->addSubmit('nextToRegister', 'Next')->onClick[] = array($this, 'confirmInfoSucceeded');

		return new StepAdapter($form, __DIR__ . '/templates/EmployeeRegister/stepForm/confirmInfo.latte');
	}

	public function previousToPersonalInfo()
	{
		$this['stepForm']->jump('personalInfo');
	}

	public function confirmInfoSucceeded()
	{
		/** @var Employee $employee */
		$employee = $this->orm->employees->findBy(['employeeNumber' => $this->getSession('employeeInfo')->employeeNumber])->fetch();
		if (isset($employee->personalInfo)) {
			$person = $employee->personalInfo;
		} else {
			$person = new Person();
		}
		if ($employee) {
			/** @var Position $position */
			$position = $this->orm->positions->findBy(['employee' => $employee->id])->fetch();
		} else {
			$employee = new Employee();
			$position = new Position();
		}
		$organization = $this->orm->organizations->findById($this->getSession('employeeInfo')->organization)->fetch();
		$jobTitle = $this->orm->jobTitles->findById($this->getSession('employeeInfo')->jobTitle)->fetch();
		$person->dateOfBirth = $this->getSession('personalInfo')->dateOfBirth;
		$person->placeOfBirth = $this->getSession('personalInfo')->placeOfBirth;
		$person->gender = $this->genderList[$this->getSession('personalInfo')->gender];
		$person->maritalStatus = $this->maritalStatusList[$this->getSession('personalInfo')->maritalStatus];
		$person->nationality = $this->getSession('personalInfo')->nationality;
		$person->permanentStay = $this->getSession('personalInfo')->permanentStay;
		$person->personalIdentityNumber = $this->getSession('personalInfo')->personalIdentityNumber;
		$person->personalPhoneNumber = $this->getSession('personalInfo')->personalPhoneNumber;

		$employee->firstName = $this->getSession('employeeInfo')->firstName;
		$employee->lastName = $this->getSession('employeeInfo')->lastName;
		$employee->personalInfo = $person;
		$employee->employeeNumber = $this->getSession('employeeInfo')->employeeNumber;
		$employee->personalEmail = $this->getSession('employeeInfo')->personalEmail;
		$employee->dateOfHire = $this->getSession('employeeInfo')->dateOfHire;
		$position->jobTitle = $jobTitle;
		$position->employee = $employee;
		$position->organization = $organization;
		try {
			$this->orm->persistAndFlush($position);
			$this['stepForm']->jump('registerStep');
		} catch (UniqueConstraintViolationException $e) {
			$this->flashMessage('Employee number duplicate', 'flash-error');
			$this['stepForm']->jump('confirmInfo');
		}
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentRegisterForm()
	{
		$form = new Form();

		$form->addText('username', 'Username:')->setRequired('Please enter your username.');
		$form->addPassword('password', 'Password:')->setRequired('Please enter your password.');
		$form->addPassword('passwordConfirm', 'PasswordConfirm:')->setRequired('Please reEnter your password.');
		$form->addSubmit('backToConfirmInfo', 'Previous')->setValidationScope(false)->onClick[] = array($this, 'previousToConfirmInfo');
		$form->addSubmit('register', 'Register')->onClick[] = array($this, 'registerFormSucceeded');

		$section = $this->getSession('registerInfo');
		$section->setExpiration(0);
		$form->setDefaults($section);
		return new StepAdapter($form, __DIR__ . '/templates/EmployeeRegister/stepForm/registerForm.latte');
	}

	public function previousToConfirmInfo()
	{
		$this['stepForm']->jump('confirmInfo');
	}

	public function registerFormSucceeded(Button $button)
	{
		$values = $button->getForm()->getValues();
		$section = $this->getSession('registerInfo');
		$section->username = $values->username;

		try {

				$this->register->verifyUsernamePassword($values->username, $values->password, $values->passwordConfirm);
				/** @var Employee $employee */
				$employee = $this->orm->employees->findBy(['employeeNumber' => $this->getSession('employeeInfo')->employeeNumber])->fetch();
				$userAccount = new UserAccount($employee);
				$userAccount->setReadOnlyValue('username', $values->username);
				$userAccount->setReadOnlyValue('password', Passwords::hash($values->password));
			if(!$this->uniqueCode) {
				$userAccount->setReadOnlyValue('newcomerKey', NULL);
				$this->orm->persistAndFlush($userAccount);

				$this->getSession('employeeInfo')->remove();
				$this->getSession('personalInfo')->remove();
				$this->getSession('registerInfo')->remove();

				$this->flashMessage('Please waiting for manager active your account!', 'flash-info');
				$this->redirect('Homepage:default');
			}else{
				$userAccount->setReadOnlyValue('newcomerKey', NULL);
				$userAccount->setReadOnlyValue('isActive', TRUE);
				$this->orm->persistAndFlush($userAccount);

				$this->getSession('employeeInfo')->remove();
				$this->getSession('personalInfo')->remove();
				$this->getSession('registerInfo')->remove();

				$storage = new FileStorage('../temp');
				$cache = new Cache($storage, 'htmlOutput');
				$cache->remove($this->uniqueCode);

				try {
					$this->user->login($values->username, $values->password);
					$this->flashMessage('Welcome to Personnel!', 'flash-info');
					$this->redirect('Homepage:default');

				} catch (AuthenticationException $e) {
					$this->flashMessage($e->getMessage(), 'flash-error');

					$this['stepForm']->jump('registerStep');
					if ($this->isAjax())
						$this->redrawControl('flashes');
				}
			}

		} catch (InvalidArgumentException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');

			$this['stepForm']->jump('registerStep');
			if ($this->isAjax())
				$this->redrawControl('flashes');
		}
	}

	public function renderInviteEmployeeRegister()
	{
		$this->template->uniqueCode = $this->uniqueCode;
	}

	public function actionInviteEmployeeRegister($str)
	{
		$storage = new FileStorage('../temp');
		$cache = new Cache($storage, 'htmlOutput');
		if($cache->load($str))
			$this->uniqueCode = $str;
	}
}
