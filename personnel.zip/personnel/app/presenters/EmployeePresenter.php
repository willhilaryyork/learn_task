<?php

namespace App\Presenters;


use App\Model\EmployeeService;
use App\Model\Persistence\Employees\Employee;
use App\Model\Persistence\Employees\EmployeesMapper;
use App\Model\Persistence\JobTitles\JobTitle;
use App\Model\Persistence\Organizations\Organization;
use App\Model\Persistence\Orm;
use App\Model\Persistence\Persons\Person;
use App\Model\Persistence\Positions\Position;
use App\Model\Persistence\UserAccounts\UserAccount;
use Nette\Application\UI\Form;
use Nette\Mail\Message;
use Nette\Utils\DateTime;
use Nette\Mail\IMailer;
use Nette\Utils\Validators;
use Nextras\Dbal\InvalidArgumentException;

class EmployeePresenter extends BasePresenter
{
	/** @var Orm @inject */
	public $orm;
	/** @var EmployeeService $employeeService @inject */
	public $employeeService;
	/** @var IMailer @inject */
	public $mailer;

	private $isEdit = false;

	private $genderList = [
		'GENDER_MALE' => 'Male',
		'GENDER_FEMALE' => 'Female',
	];

	private $maritalStatusList = [
		'MARITAL_STATUS_SINGLE' => 'Single',
		'MARITAL_STATUS_MARRIED' => 'Married',
		'MARITAL_STATUS_DIVORCED' => 'Divorced',
		'MARITAL_STATUS_WIDOWED' => 'Widowed',
		'MARITAL_STATUS_LIVING_COMMON_LAW' => 'Living common law',
		'MARITAL_STATUS_SEPARATED' => 'Separated',
	];

	private $employeeId;

	/** inactive current employee id */
	private $inactiveEmployeeId;

	private $searchConditions = [
		'Employee_Number' => 'Employee Number',
		'First_Name' => 'Employee First Name',
		'Last_Name' => 'Employee Last Name',
	];

	public $searchEmployees;

	private $isSearchEmployee = false;
	/**
	 * @var EmployeesMapper $employeesMapper @inject
	 */
	public $employeesMapper;

	public function beforeRender()
	{
		if (!$this->getUser()->isLoggedIn())
			$this->redirect('Sign:in');
	}

	public function renderDefault()
	{
		$this->redirect('Employee:employeeList');
	}

	/**
	 * @param int $pageLimit
	 */
	public function renderEmployeeList($pageLimit)
	{
		$limit = isset($pageLimit) ? $pageLimit : 8;
		$page = $this->getParameter('page') ? $this->getParameter('page') : 1;
		$offset = ($page - 1) * $limit;
		if (!$this->isSearchEmployee) {
			$totalRecord = $this->orm->positions->findAll()->count();
			$this->template->positions = $this->orm->positions->findAll()->orderBy('employee')->limitBy($limit, $offset)->fetchAll();
		} else {
			$totalRecord = count($this->searchEmployees);
			$this->template->positions = $this->searchEmployees;
		}
		$totalPage = ceil($totalRecord / $limit);
		$this->template->isSearchEmployee = $this->isSearchEmployee;
		$this->template->page = $page;
		$this->template->totalPage = $totalPage;
		$this->template->pageLimit = $limit;
	}

	public function renderAddNewEmployee()
	{
		$this->prepareEmployeeFormInfo();
	}

	public function prepareEmployeeFormInfo()
	{
		$this->template->jobTitleLists = $this->orm->jobTitles->findAll()->fetchPairs('id', 'name');
		$this->template->organizationLists = $this->orm->organizations->findAll()->fetchPairs('id', 'name');
		$this->template->responsibilitiesLists = $this->orm->responsibilities->findAll()->fetchPairs('id', 'name');
	}

	public function actionEditEmployeeInfo($employeeId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}

		$this->prepareEmployeeFormInfo();

		$this->employeeId = $employeeId;
		/** @var Employee $employee */
		$employee = $this->orm->employees->getById($employeeId);
		if (!$employee) {
			$this->flashMessage('Employee not found', 'flash-error');
			$this->redirect('Employee:default');
		}

		$hasAccount = false;
		$accountIsActive = false;
		/** @var UserAccount $userAccount */
		$userAccount = $this->orm->userAccounts->findBy(['employee' => $employeeId])->fetch();
		if ($userAccount) {
			$hasAccount = true;
			$accountIsActive = $userAccount->isActive ? true : false;
		}

		$responsibility = $employee->responsibilities;
		$responsibilities = [];
		foreach ($responsibility as $item) {
			$responsibilities[] = $item;
		}
		$hasResponsibility = $responsibilities == [];

		$positions = $this->orm->positions->findBy(['employee' => $employeeId])->fetchAll();

		$this->template->employee = $employee;
		$this->template->hasAccount = $hasAccount;
		$this->template->accountIsActive = $accountIsActive;
		$this->template->hasResponsibility = $hasResponsibility;
		$this->template->positions = $this->employeeService->transferPositionsToArray($positions);

		$this->displayEmployeeInfo($employeeId);
	}

	public function actionApproveCurrentEmployee($employeeId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}

		$this->prepareEmployeeFormInfo();

		$this->inactiveEmployeeId = $employeeId;
		/** @var Employee $employee */
		$employee = $this->orm->employees->getById($employeeId);
		if (!$employee) {
			$this->flashMessage('Employee not found', 'flash-error');
			$this->redirect('Employee:default');
		}

		$this->displayEmployeeInfo($employeeId);
	}

	public function displayEmployeeInfo($employeeId)
	{
		/** @var Employee $employee */
		$employee = $this->orm->employees->getById($employeeId);
		$this->template->employee = $employee;

		$positions = $this->orm->positions->findBy(['employee' => $employeeId])->fetchAll();

		$this->template->positions = $this->employeeService->transferPositionsToArray($positions);

		$this['addNewEmployeeForm']->setDefaults(
			[
				'firstName' => $employee->firstName,
				'lastName' => $employee->lastName,
				'employeeNumber' => $employee->employeeNumber,
				'personalEmail' => $employee->personalEmail,
				'dateOfHire' => $employee->dateOfHire->format('m-d-Y'),
			]);
	}

	public function createComponentAddNewEmployeeForm()
	{
		$form = new Form();
		$form->addText('firstName', 'First Name')->setRequired();
		$form->addText('lastName', 'Last Name')->setRequired();
		$form->addText('employeeNumber', 'Employee Number')->setRequired();
		$form->addText('dateOfHire', 'Date Of Hire')->setRequired();
		$form->addText('personalEmail', 'E-Mail');
		$form->addSubmit('submit', 'SAVE');

		$form->onSuccess[] = array($this, 'addNewEmployeeSucceeded');
		return $form;
	}

	public function addNewEmployeeSucceeded($form, $values)
	{
		$organizationValues = $_POST['organization'];
		$jobTitleValues = $_POST['jobTitle'];
		$isDirectorValues = $_POST['isDirector'];

		if ($this->checkEmployeeInfo($values)) {

			if (!$this->employeeId && !$this->inactiveEmployeeId) { //add new employee
				/** @var Employee $employee */
				$employee = new Employee();

				/** @var Position $positions */
				$positions = [];

				$action = 'add';
			} elseif ($this->employeeId && !$this->inactiveEmployeeId) { //edit employee
				/** @var Employee $employee */
				$employee = $this->orm->employees->findById($this->employeeId)->fetch();

				/** @var Position $positions */
				$positions = $this->orm->positions->findBy(['employee' => $this->employeeId])->fetchAll();

				$action = 'edit';
			} else { //approve employee
				/** @var Employee $employee */
				$employee = $this->orm->employees->findById($this->inactiveEmployeeId)->fetch();

				/** @var Position $positions */
				$positions = $this->orm->positions->findBy(['employee' => $this->inactiveEmployeeId])->fetchAll();

				$action = 'approve';
			}

			$this->employeeService->saveEmployeeInfo($employee, $values);

			if ($positions) {
				foreach ($positions as $position)
					$this->orm->remove($position);
			}

			for ($i = 0; $i < count($organizationValues); $i++) {
				/** @var JobTitle $jobTitle */
				$jobTitle = $this->orm->jobTitles->findBy(['id' => $jobTitleValues[$i]])->fetch();
				/** @var Organization $organization */
				$organization = $this->orm->organizations->findBy(['id' => $organizationValues[$i]])->fetch();

				$positionValues = [
					'employee' => $employee,
					'jobTitle' => $jobTitle,
					'organization' => $organization,
					'isDirector' => $isDirectorValues[$i],
				];
				/** @var Position $position */
				$position = new Position();

				$this->employeeService->saveEmployeePosition($positionValues, $position);
			}

			if ($action == 'add') {
				$this->flashMessage('Employee ' . $employee->name . ' add success!', 'flash-info');
				$this->redirect('Employee:generateNewUserKey', $employee->id);
			} elseif ($action == 'edit') {
				$this->flashMessage('Employee ' . $employee->name . ' \'s info modify success!', 'flash-info');
				$this->redirect('Employee:editEmployeeInfo', $employee->id);
			} else {
				$this->flashMessage('Employee ' . $employee->name . ' active success!', 'flash-info');
				/** @var UserAccount $userAccount */
				$userAccount = $this->orm->userAccounts->findBy(['employee' => $this->inactiveEmployeeId])->fetch();
				$userAccount->setReadOnlyValue('isActive', TRUE);
				$this->orm->persistAndFlush($userAccount);
				$this->flashMessage('"' . $employee->name . '" is active', 'flash-info');
				$this->redirect('Employee:viewWaitingForActive');
			}
		}
	}

	private function checkEmployeeInfo($values)
	{
		$organizationValues = $_POST['organization'];
		$isDirectorValues = $_POST['isDirector'];

		if (!preg_match('/^[A-Z0-9]+$/', $values['employeeNumber'])) {
			$this->flashMessage('Employee Number can only contain number 0~9 and capital letters', 'flash-error');
			return false;
		}

		if ($values['personalEmail'] != '' && !Validators::isEmail($values['personalEmail'])) {
			$this->flashMessage('Personal E-mail format error, please check!', 'flash-info');
			return false;
		}

		if (count(array_unique($organizationValues)) != count($organizationValues)) {
			$this->flashMessage('One organization can have only one jobTitle, please reselect!', 'flash-error');
			return false;
		}

		for ($i = 0; $i < count($organizationValues); $i++) {
			/** @var Organization $organization */
			$organization = $this->orm->organizations->findBy(['id' => $organizationValues[$i]])->fetch();

			if ($isDirectorValues[$i] == '1' && $organization->director != null
				&& $organization->director->employee->name != $values['firstName'] . ' ' . $values['lastName']
			) {
				$this->flashMessage($organization->name . ' already has director '
					. $organization->director->employee->name
					. ', please unchecked!', 'flash-info');
				return false;
			}
		}
		return true;
	}

	public function renderApproveCurrentEmployee()
	{
		$this->template->inactiveEmployeeId = $this->inactiveEmployeeId;
	}

	public function renderGenerateNewUserKey($newEmployeeID)
	{
		try {
			$newUserKeyAndPosition = $this->employeeService->getNewUserKeyAndUserInfo($newEmployeeID);
		} catch (InvalidArgumentException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');
		}

		if (isset($newUserKeyAndPosition[1])) {
			$positions = $newUserKeyAndPosition[1];
			$employee = $positions[0]->employee;
		}

		$this->template->userKey = isset($newUserKeyAndPosition[0]) ? $newUserKeyAndPosition[0] : null;
		$this->template->position = isset($positions) ? $this->employeeService->transferPositionsToArray($positions) : null;
		$this->template->employee = isset($employee) ? $employee : null;
	}

	public function renderViewUnregNewComers()
	{
		$this->template->userAccounts = $this->orm->userAccounts->findBy(['isActive' => false])->fetchAll();
	}

	public function renderViewWaitingForActive()
	{
		$this->template->userAccounts = $this->orm->userAccounts->findBy(['isActive' => false])->fetchAll();
	}

	public function createComponentEmployeePersonalInfoForm()
	{
		$form = new Form();
		$form->addText('dateOfBirth', 'Birth Day')->setRequired();
		$form->addText('placeOfBirth', 'Birth Place')->setRequired();
		$form->addSelect('gender', 'Gender', $this->genderList)->setRequired();
		$form->addSelect('maritalStatus', 'Marital Status', $this->maritalStatusList)->setRequired();
		$form->addText('nationality', 'Nationality')->setRequired();
		$form->addText('permanentStay', 'Permanent Stay')->setRequired();
		$form->addText('personalIdentityNumber', 'ID Number')->setRequired();
		$form->addText('personalEmail', 'Personal Email');
		$form->addText('personalPhoneNumber', 'Personal Phone Number')->setRequired();

		$form->addSubmit('submit', 'ADD');

		$form->onSuccess[] = array($this, 'employeePersonalInfoSuccess');
		return $form;
	}

	public function employeePersonalInfoSuccess($form, $values)
	{
		$logInEmployeeID = isset($this->user->getIdentity()->employeeId) ? $this->user->getIdentity()->employeeId : null;
		/**
		 * @var Employee $employee
		 */
		$employee = $this->orm->employees->getById($logInEmployeeID);

		if ($this->isEdit)
			$person = $this->orm->persons->getById($employee->personalInfo);
		else
			$person = new Person();
		$person->dateOfBirth = $values['dateOfBirth'];
		$person->placeOfBirth = $values['placeOfBirth'];
		$person->gender = $this->genderList[$values['gender']];
		$person->maritalStatus = $this->maritalStatusList[$values['maritalStatus']];
		$person->nationality = $values['nationality'];
		$person->permanentStay = $values['permanentStay'];
		$person->personalIdentityNumber = $values['personalIdentityNumber'];
		$person->personalPhoneNumber = $values['personalPhoneNumber'];

		$employee->personalInfo = $person;

		$this->orm->persistAndFlush($employee);
		$this->redirect('Employee:employeeProfile');
	}

	public function renderEmployeeProfile()
	{
		$logInEmployeeID = isset($this->user->getIdentity()->employeeId) ? $this->user->getIdentity()->employeeId : null;
		$positions = $this->orm->positions->findBy(['employee' => $logInEmployeeID])->fetchAll();

		$employee = $positions[0]->employee;

		$this->template->employee = $employee;
		$this->template->position = $this->employeeService->transferPositionsToArray($positions);
	}

	/**
	 * @param int $employeeId
	 */
	public function actionEditEmployeePersonalInfo($employeeId)
	{
		if (!$this->getUser()->isLoggedIn()) {
			$this->redirect('Sign:in');
		}

		$logInEmployeeID = isset($this->user->getIdentity()->employeeId) ? $this->user->getIdentity()->employeeId : null;
		$logInEmployeeIsDirector = $this->orm->positions->findBy(['employee' => $logInEmployeeID])->fetch()->isDirector;

		$employeeId = isset($employeeId) ? $employeeId : $logInEmployeeID;


		if (!$logInEmployeeIsDirector && $logInEmployeeID != $employeeId) {
			$this->flashMessage('You have no right to do this action!', 'flash-info');
			$this->redirect('Homepage:default');
		}
		$this->isEdit = true;

		/** @var Employee $employee */
		$employee = $this->orm->employees->findById($employeeId)->fetch();
		$this->template->dateOfBirth = $employee->personalInfo->dateOfBirth;

		$arr = array(
			'dateOfBirth' => $employee->personalInfo->dateOfBirth,
			'placeOfBirth' => $employee->personalInfo->placeOfBirth,
			'gender' => array_search($employee->personalInfo->gender, $this->genderList),
			'maritalStatus' => array_search($employee->personalInfo->maritalStatus, $this->maritalStatusList),
			'nationality' => $employee->personalInfo->nationality,
			'permanentStay' => $employee->personalInfo->permanentStay,
			'personalIdentityNumber' => $employee->personalInfo->personalIdentityNumber,
			'personalPhoneNumber' => $employee->personalInfo->personalPhoneNumber,
		);
		$tempDate = new DateTime($arr['dateOfBirth']);
		$arr['dateOfBirth'] = $tempDate->format('Y-m-d');
		$this['employeePersonalInfoForm']->setDefaults($arr);
	}

	public function createComponentChangePasswordForm()
	{
		$username = $this->user->getIdentity()->employeeFirstName . ' ' . $this->user->getIdentity()->employeeLastName;
		/** @var Employee $employee */
		$employee = $this->orm->employees->findById($this->user->getIdentity()->employeeId)->fetch();

		$form = new Form();
		$form->addText('name', 'Name')->setDisabled()->setDefaultValue($username);
		$form->addText('employeeNumber', 'Employee Number')->setDisabled()->setDefaultValue($employee->employeeNumber);
		$form->addPassword('originPassword', 'Origin Password')->setRequired();
		$form->addPassword('newPassword', 'New Password')->setRequired();
		$form->addPassword('confirmNewPassword', 'Confirm New Password')->setRequired();
		$form->addSubmit('save', 'Save');
		$form->onSuccess[] = [$this, 'changePasswordSucceeded'];

		return $form;
	}

	public function changePasswordSucceeded($form, $values)
	{
		try {
			$this->employeeService->changePassword($this->user->getIdentity()->employeeId, $values);
			$this->redirect('Employee:employeeProfile');
		} catch (InvalidArgumentException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');
		}
	}

	public function handleSendAccessKeyMail()
	{
		$employeeId = $this->getParameter('newEmployeeID');
		/** @var Position $position */
		$position = $this->orm->positions->findBy(['employee' => $employeeId])->fetch();
		/** @var UserAccount $userAccount */
		$userAccount = $this->orm->userAccounts->findBy(['employee' => $employeeId])->fetch();

		if ($position->employee->personalEmail != '') {
			$mail = new Message();
			$mail->setFrom('robot@personnel.com', 'Personnel Robot');
			$mail->addTo($position->employee->personalEmail, $position->employee->name);
			$mail->setSubject('Access Key');
			$mail->setHtmlBody('Hello ' . $position->employee->name
				. ',<br><br>Your access key is :<br><b>' . $userAccount->newcomerKey . '</b><br><br>'
				. 'Please visit this page to active your account.<br>'
				. $this->template->baseUrl . '/register');

			$this->mailer->send($mail);
			$this->redirect('this');
		} else
			$this->flashMessage('Can not send E-Mail, because email not set!', 'flash-error');
	}

	public function createComponentResetEmployeePasswordForm()
	{
		$form = new Form();
		$form->addText('resetPassword', 'Reset Password')->setRequired();
		$form->addSubmit('save', 'Save');

		$form->onSuccess[] = [$this, 'resetEmployeePasswordSucceeded'];
		return $form;
	}

	public function resetEmployeePasswordSucceeded($form, $values)
	{
		$this->employeeService->resetPassword($this->employeeId, $values['resetPassword']);
		$this->flashMessage('Employee password change to ' . $values['resetPassword'] . ' success!', 'flash-info');
		$this->redirect('this');
	}

	public function handleDeleteEmployee($employeeId)
	{
		$loggedUserId = $this->getUser()->id;

		$result = $this->employeeService->deleteEmployee($employeeId, $loggedUserId);

		if (!$result) {
			$this->flashMessage('You cannot delete yourself!', 'flash-error');
		} else {
			$this->flashMessage('delete success!', 'flash-info');
		}
		$this->redirect('Employee:default');
	}

	public function handleGenerateAccessKey()
	{
		$this->redirect('Employee:generateNewUserKey?newEmployeeID=' . $this->employeeId . '}');
	}

	public function createComponentAddResponsibilitiesForm()
	{
		$responsibilityLists = $this->orm->responsibilities->findAll()->fetchPairs('id', 'name');

		$form = new Form();
		$form->addMultiSelect('responsibilities', 'Responsibilities', $responsibilityLists)->setRequired();
		$form->addSubmit('save', 'Save');

		$form->onSuccess[] = [$this, 'addResponsibilitiesSucceeded'];
		return $form;
	}

	public function addResponsibilitiesSucceeded($form, $values)
	{
		/** @var Employee $employee */
		$employee = $this->orm->employees->findBy(['id' => $this->employeeId])->fetch();

		$responsibility = [];
		foreach ($values['responsibilities'] as $resp)
			$responsibility[] = $resp;

		$employee->responsibilities = $responsibility;

		$this->orm->employees->persistAndFlush($employee, true);
		$this->redirect('this');
	}

	public function handleEditResponsibilities()
	{
		/** @var Employee $employee */
		$employee = $this->orm->employees->findBy(['id' => $this->employeeId])->fetch();

		$responsibility = $employee->responsibilities;
		$responsibilities = [];
		foreach ($responsibility as $item)
			$responsibilities[] = $item->id;

		$this['addResponsibilitiesForm']->setDefaults(['responsibilities' => $responsibilities]);
		$this->redrawControl('editResponsibilitiesForm');
	}

	public function createComponentSearchEmployee()
	{
		$form = new Form();
		$form->addText('searchContent', 'search Content');
		$form->addSubmit('searchSubmit', 'search Submit');

		$form->onSuccess[] = [$this, 'searchEmployeeSucceeded'];
		return $form;
	}

	public function searchEmployeeSucceeded($form, $values)
	{
		$positions = [];
		$employees = $this->employeesMapper->searchEmployee($values->searchContent);
		foreach ($employees as $employee)
			$positions[] = $this->orm->positions->findBy(['employee' => $employee->id])->fetchAll();
		$this->searchEmployees = $this->multiArrayToArray($positions);
		if ($values->searchContent != "")
			$this->isSearchEmployee = true;
	}

	public function multiArrayToArray($multi)
	{
		$arr = [];
		foreach ($multi as $key => $val) {
			if (is_array($val)) {
				$arr = array_merge($arr, $this->multiArrayToArray($val));
			} else {
				$arr[] = $val;
			}
		}
		return $arr;
	}
}