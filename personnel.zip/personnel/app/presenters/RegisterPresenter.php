<?php

namespace App\Presenters;

use App\Components\StepForm\StepAdapter;
use App\Components\StepForm\StepFormControl;
use App\Model\EmployeeService;
use App\Model\Persistence\Orm;
use App\Model\Persistence\UserAccounts\UserAccount;
use App\Model\Register;
use Nette;
use Nette\Application\UI\Form;

class RegisterPresenter extends BasePresenter
{
	/** @var  Orm $orm @inject */
	public $orm;
	/** @var  Register $register @inject */
	public $register;
	/**  @var EmployeeService $employeeService @inject */
	public $employeeService;

	public function createComponentStepForm()
	{
		$control = new StepFormControl();
		$control->setCustomTemplate(__DIR__ . '/templates/Register/stepForm/form.latte');

		$control->addStep('New Comer Key Check', $this->getComponent('newComerKeyForm'), 'newComerKeyCheck');

		$employee = $this->getComponent('employeeInfoForm');
		$newComerKey = $this->getSession('keyInfo')->newComerKey;
		if ($newComerKey) {
			/** @var UserAccount $userAccount */
			$userAccount = $this->orm->userAccounts->findBy(['newcomerKey' => $newComerKey])->fetch();
			if ($userAccount) {
				$employee->template->employee = $userAccount->employee;

				$positions = $this->orm->positions->findBy(['employee' => $userAccount->employee->id])->fetchAll();

				$employee->template->position = $this->employeeService->transferPositionsToArray($positions);
			}
		}
		$control->addStep('Employee Info Check', $employee, 'employeeInfoCheck');

		$control->addStep('Register', $this->getComponent('registerForm'), 'registerStep');

		return $control;
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentNewComerKeyForm()
	{
		$form = new Form();

		$form->addText('newComerKey', 'New Comer Key:')->setRequired('Please enter your key.');
		$form->addSubmit('nextToEmployeeInfo', 'Next');
		$form->onSuccess[] = array($this, 'newComerKeyFormSucceeded');

		$section = $this->getSession('keyInfo');
		$section->setExpiration(0);
		$form->setDefaults($section);

		return new StepAdapter($form, __DIR__ . '/templates/Register/stepForm/newComerKeyForm.latte');
	}

	public function newComerKeyFormSucceeded(Form $form, $values)
	{
		/** @var UserAccount $userAccount */
		$userAccount = $this->orm->userAccounts->findBy(['newcomerKey' => $values->newComerKey])->fetch();

		$section = $this->getSession('keyInfo');
		$section->newComerKey = $values->newComerKey;

		if ($userAccount) {
			$this['stepForm']->jump('employeeInfoCheck');
		} else {
			$this->flashMessage('Your new comer key is wrong!', 'flash-error');

			if ($this->isAjax())
				$this->redrawControl('flashes');
		}
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentEmployeeInfoForm()
	{
		$form = new Form();

		$form->addSubmit('backToNewComerKey', 'Previous')->onClick[] = array($this, 'previousToComerKeyCheck');
		$form->addSubmit('nextToRegister', 'Next')->onClick[] = array($this, 'employeeInfoFormSucceeded');

		return new StepAdapter($form, __DIR__ . '/templates/Register/stepForm/employeeInfoForm.latte');
	}

	public function previousToComerKeyCheck()
	{
		$this['stepForm']->jump('newComerKeyCheck');
	}

	public function employeeInfoFormSucceeded()
	{
		$this['stepForm']->jump('registerStep');
	}

	/**
	 * @return StepAdapter
	 */
	public function createComponentRegisterForm()
	{
		$form = new Form();

		$form->addText('username', 'Username:')->setRequired('Please enter your username.');
		$form->addPassword('password', 'Password:')->setRequired('Please enter your password.');
		$form->addPassword('passwordConfirm', 'PasswordConfirm:')->setRequired('Please reEnter your password.');
		$form->addSubmit('backToEmployeeInfo', 'Previous')->setValidationScope(false)->onClick[] = array($this, 'previousToEmployeeInfoCheck');
		$form->addSubmit('register', 'Register')->onClick[] = array($this, 'registerFormSucceeded');

		$section = $this->getSession('registerInfo');
		$section->setExpiration(0);
		$form->setDefaults($section);
		return new StepAdapter($form, __DIR__ . '/templates/Register/stepForm/registerForm.latte');
	}

	public function previousToEmployeeInfoCheck()
	{
		$this['stepForm']->jump('employeeInfoCheck');
	}

	public function registerFormSucceeded(Nette\Forms\Controls\Button $button)
	{
		$values = $button->getForm()->getValues();
		$section = $this->getSession('registerInfo');
		$section->username = $values->username;

		try {
			$this->register->verifyUsernamePassword($values->username, $values->password, $values->passwordConfirm);

			$newComerKey = $this->getSession('keyInfo')->newComerKey;
			if ($newComerKey) {
				/** @var UserAccount $userAccount */
				$userAccount = $this->orm->userAccounts->findBy(['newcomerKey' => $newComerKey])->fetch();
				if ($userAccount) {
					$userAccount->activate($values->username, $values->password);
					$this->orm->persistAndFlush($userAccount);
				}
			} else {
				$this->flashMessage('Please key in your new comer key at new comer key check step!', 'flash-error');
				$this['stepForm']->jump('registerStep');
			}

			$this->getSession('keyInfo')->remove();
			$this->getSession('registerInfo')->remove();

			try {
				$this->user->login($values->username, $values->password);
				$this->flashMessage('Welcome to Personnel!', 'flash-info');
				$this->redirect('Homepage:default');

			} catch (Nette\Security\AuthenticationException $e) {
				//$form->addError($e->getMessage());
				$this->flashMessage($e->getMessage(), 'flash-error');

				$this['stepForm']->jump('registerStep');
				if ($this->isAjax())
					$this->redrawControl('flashes');
			}
		} catch (Nette\InvalidArgumentException $e) {
			$this->flashMessage($e->getMessage(), 'flash-error');

			$this['stepForm']->jump('registerStep');
			if ($this->isAjax())
				$this->redrawControl('flashes');
		}

	}
}
