UPDATE `user_accounts` SET `employee_id`=NULL WHERE `id`='1';
DELETE FROM `employees` WHERE `id`='13';
