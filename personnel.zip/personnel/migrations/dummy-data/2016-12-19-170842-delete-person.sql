DELETE FROM `employees` WHERE `id`='1';
DELETE FROM `persons` WHERE `id`='1';