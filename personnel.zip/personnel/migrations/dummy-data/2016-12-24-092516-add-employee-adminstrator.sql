INSERT INTO `employees` (`first_name`, `last_name`, `employee_number`, `date_of_hire`, `job_title_id`) VALUES ('admin', 'admin', 'admin', '2000-01-01', '1');
