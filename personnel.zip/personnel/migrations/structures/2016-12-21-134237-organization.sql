CREATE TABLE `organization_types` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC));

  CREATE TABLE `organizations` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `organization_type_id` INT NOT NULL,
  `parent_id` INT NULL,
  `director_id` INT NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `organizations`
ADD UNIQUE INDEX `organization_uk` (`name` ASC, `parent_id` ASC);


ALTER TABLE `organizations`
ADD INDEX `m-1_organization_tupe_fk_idx` (`organization_type_id` ASC),
ADD INDEX `m-1_parent_fk_idx` (`parent_id` ASC),
ADD INDEX `1-1_director_fk_idx` (`director_id` ASC);
ALTER TABLE `organizations`
ADD CONSTRAINT `m-1_organization_tupe_fk`
  FOREIGN KEY (`organization_type_id`)
  REFERENCES `organization_types` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `m-1_parent_fk`
  FOREIGN KEY (`parent_id`)
  REFERENCES `organizations` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `1-1_director_fk`
  FOREIGN KEY (`director_id`)
  REFERENCES `employees` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `organizations`
DROP FOREIGN KEY `m-1_organization_tupe_fk`;
ALTER TABLE `organizations`
CHANGE COLUMN `organization_type_id` `type_id` INT(11) NOT NULL ;
ALTER TABLE `organizations`
ADD CONSTRAINT `m-1_organization_tupe_fk`
FOREIGN KEY (`type_id`)
REFERENCES `organization_types` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `organizations`
DROP FOREIGN KEY `m-1_organization_tupe_fk`;
ALTER TABLE `organizations`
DROP INDEX `m-1_organization_tupe_fk_idx` ,
ADD INDEX `m-1_type_fk_idx` (`type_id` ASC);
ALTER TABLE `organizations`
ADD CONSTRAINT `m-1_type_fk`
FOREIGN KEY (`type_id`)
REFERENCES `organization_types` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `employees`
DROP COLUMN `work_group`;

ALTER TABLE `employees`
ADD COLUMN `organization_id` INT NULL AFTER `job_title_id`;

ALTER TABLE `employees`
ADD INDEX `m-1_organization_fk_idx` (`organization_id` ASC);
ALTER TABLE `employees`
ADD CONSTRAINT `m-1_organization_fk`
FOREIGN KEY (`organization_id`)
REFERENCES `organizations` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `employees`
ADD COLUMN `is_director` TINYINT(1) UNSIGNED NOT NULL AFTER `organization_id`;

ALTER TABLE `organizations`
DROP FOREIGN KEY `1-1_director_fk`;
ALTER TABLE `organizations`
DROP COLUMN `director_id`,
DROP INDEX `1-1_director_fk_idx` ;


ALTER TABLE `employees`
DROP FOREIGN KEY `m-1_organization_fk`;
ALTER TABLE `employees`
CHANGE COLUMN `organization_id` `organization_id` INT(11) NOT NULL ;
ALTER TABLE `employees`
ADD CONSTRAINT `m-1_organization_fk`
FOREIGN KEY (`organization_id`)
REFERENCES `organizations` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

