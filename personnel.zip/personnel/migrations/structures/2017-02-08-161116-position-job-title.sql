ALTER TABLE `positions` 
ADD COLUMN `job_title_id` INT(11) NOT NULL AFTER `organization_id`;
