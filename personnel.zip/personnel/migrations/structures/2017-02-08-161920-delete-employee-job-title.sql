ALTER TABLE `employees` 
DROP FOREIGN KEY `1-m_job_title_fk`;
ALTER TABLE `employees` 
DROP COLUMN `job_title_id`,
DROP INDEX `1-m_job_title_fk_idx` ;
