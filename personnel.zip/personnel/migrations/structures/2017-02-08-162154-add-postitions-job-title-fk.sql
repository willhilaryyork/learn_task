ALTER TABLE `positions` 
ADD INDEX `m-1_job_title_fk_idx` (`job_title_id` ASC);
ALTER TABLE `positions` 
ADD CONSTRAINT `m-1_job_title_fk`
  FOREIGN KEY (`job_title_id`)
  REFERENCES `job_titles` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
