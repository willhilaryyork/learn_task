CREATE TABLE `responsibilities` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `employees_x_responsibilities` (
  `employee_id` INT NOT NULL,
  `responsibility_id` INT NOT NULL,
  PRIMARY KEY (`employee_id`, `responsibility_id`));

ALTER TABLE `employees_x_responsibilities`
ADD INDEX `m-n_responsibility_fk_idx` (`responsibility_id` ASC);
ALTER TABLE `employees_x_responsibilities`
ADD CONSTRAINT `m-n_employee_fk`
  FOREIGN KEY (`employee_id`)
  REFERENCES `employees` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `m-n_responsibility_fk`
  FOREIGN KEY (`responsibility_id`)
  REFERENCES `responsibilities` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
