CREATE TABLE `persons` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `date_of_birth` DATETIME NOT NULL,
  `place_of_birth` VARCHAR(255) NOT NULL,
  `gender` ENUM('Male', 'Female') NOT NULL,
  `marital_status` ENUM('Married', 'Single', 'Divorced', 'Widowed', 'Living common law', 'Separated') NOT NULL,
  `nationality` VARCHAR(255) NOT NULL,
  `permanent_stay` VARCHAR(255) NOT NULL,
  `personal_identity_number` VARCHAR(255) NOT NULL,
  `personal_email` VARCHAR(255) NULL,
  `personal_phone_number` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `personal_identity_number_UNIQUE` (`personal_identity_number` ASC));

CREATE TABLE `employees` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(255) NOT NULL,
  `last_name` VARCHAR(255) NOT NULL,
  `personal_info_id` INT NULL,
  `employee_number` VARCHAR(255) NOT NULL,
  `date_of_hire` DATETIME NOT NULL,
  `position` VARCHAR(45) NULL,
  `work_group` VARCHAR(45) NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `employee_number_UNIQUE` (`employee_number` ASC));

ALTER TABLE `employees`
ADD INDEX `1-1_person_fk_idx` (`personal_info_id` ASC);
ALTER TABLE `employees`
ADD CONSTRAINT `1-1_person_fk`
FOREIGN KEY (`personal_info_id`)
REFERENCES `persons` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
