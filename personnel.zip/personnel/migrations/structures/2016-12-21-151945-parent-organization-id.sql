ALTER TABLE `organizations`
DROP FOREIGN KEY `m-1_parent_fk`;
ALTER TABLE `organizations`
CHANGE COLUMN `parent_id` `parent_organization_id` INT(11) NULL DEFAULT NULL ;
ALTER TABLE `organizations`
ADD CONSTRAINT `m-1_parent_fk`
  FOREIGN KEY (`parent_organization_id`)
  REFERENCES `organizations` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
