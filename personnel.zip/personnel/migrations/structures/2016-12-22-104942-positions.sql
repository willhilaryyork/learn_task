CREATE TABLE `positions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `employee_id` INT NOT NULL,
  `organization_id` INT NOT NULL,
  `is_director` TINYINT(1) NOT NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `employees`
DROP COLUMN `is_director`;

ALTER TABLE `employees`
DROP FOREIGN KEY `m-1_organization_fk`;
ALTER TABLE `employees`
DROP COLUMN `organization_id`,
DROP INDEX `m-1_organization_fk_idx` ;


ALTER TABLE `positions`
ADD INDEX `m-1_employee_fk_idx` (`employee_id` ASC),
ADD INDEX `m-1_organization_fk_idx` (`organization_id` ASC);
ALTER TABLE `positions`
ADD CONSTRAINT `m-1_employee_fk`
  FOREIGN KEY (`employee_id`)
  REFERENCES `employees` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `m-1_organization_fk`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organizations` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
