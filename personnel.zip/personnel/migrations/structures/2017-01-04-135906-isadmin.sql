ALTER TABLE `user_accounts`
ADD COLUMN `is_admin` TINYINT(1) UNSIGNED NOT NULL AFTER `employee_id`;