ALTER TABLE `user_accounts`
DROP FOREIGN KEY `employee_fk`;
ALTER TABLE `user_accounts`
CHANGE COLUMN `employee_id` `employee_id` INT(11) NULL ;
ALTER TABLE `user_accounts`
ADD CONSTRAINT `employee_fk`
  FOREIGN KEY (`employee_id`)
  REFERENCES `employees` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
