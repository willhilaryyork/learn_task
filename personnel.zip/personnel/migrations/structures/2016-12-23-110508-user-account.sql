CREATE TABLE `user_accounts` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(255) NULL,
  `password` VARCHAR(255) NULL,
  `is_active` TINYINT(1) UNSIGNED NOT NULL,
  `newcomer_key` VARCHAR(255) NULL,
  `employee_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC),
  UNIQUE INDEX `newcomer_key_UNIQUE` (`newcomer_key` ASC),
  UNIQUE INDEX `employee_id_UNIQUE` (`employee_id` ASC));

ALTER TABLE `user_accounts`
ADD CONSTRAINT `employee_fk`
  FOREIGN KEY (`employee_id`)
  REFERENCES `personnel`.`employees` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `employees`
CHANGE COLUMN `employee_number` `employee_number` VARCHAR(10) NOT NULL ;

