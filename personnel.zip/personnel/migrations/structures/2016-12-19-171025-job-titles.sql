CREATE TABLE `job_titles` (
  `id`          INT          NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(255) NOT NULL,
  `description` VARCHAR(255) NULL,
  PRIMARY KEY (`id`)
);

ALTER TABLE `employees`
DROP COLUMN `position`;

ALTER TABLE `employees`
ADD COLUMN `job_title_id` INT NOT NULL AFTER `work_group`;

ALTER TABLE `employees`
ADD INDEX `1-n_job_title_fk_idx` (`job_title_id` ASC);
ALTER TABLE `employees`
ADD CONSTRAINT `1-m_job_title_fk`
  FOREIGN KEY (`job_title_id`)
  REFERENCES `job_titles` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `employees`
DROP INDEX `1-n_job_title_fk_idx` ,
ADD INDEX `1-m_job_title_fk_idx` (`job_title_id` ASC);