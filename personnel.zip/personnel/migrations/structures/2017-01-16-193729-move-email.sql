ALTER TABLE `employees`
ADD COLUMN `personal_email` VARCHAR(255) NULL DEFAULT NULL AFTER `employee_number`;

ALTER TABLE `persons`
DROP COLUMN `personal_email`;
